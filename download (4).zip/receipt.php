<?php
require_once __DIR__ . '/config.php';
require_once __DIR__ . '/gcash.php';
require_once __DIR__ . '/guest_content.php';
require_login();
$isCustomer = $_SESSION['role'] === 'customer';
$customerId = (int) ($_SESSION['user_id'] ?? $_SESSION['id'] ?? 0);

$conn = db_connect();

$id = isset($_GET["id"]) ? (int)$_GET["id"] : 0;
if ($isCustomer && !customer_owns_paid_reservation($conn, $id, $customerId)) {
    http_response_code(404);
    exit('Receipt not found.');
}

$result = mysqli_query($conn, "
    SELECT reservations.*, rooms.room_name, rooms.room_rate, rooms.room_type,
        reservation_states.state AS reservation_state,
        reservation_states.scheduled_check_in, reservation_states.scheduled_check_out,
        reservation_states.actual_check_in, reservation_states.actual_check_out
    FROM reservations
    LEFT JOIN rooms ON reservations.room_id = rooms.id
    LEFT JOIN reservation_states ON reservation_states.reservation_id = reservations.id
    WHERE reservations.id = '$id'
");

$row = $result ? mysqli_fetch_assoc($result) : null;
if ($row === null) {
    http_response_code(404);
}
$onlinePayment = null;
if ($isCustomer && $row) {
    $statement = $conn->prepare("SELECT amount, paid_at FROM payment_attempts WHERE reservation_id = ? AND customer_id = ? AND status = 'paid' ORDER BY id DESC LIMIT 1");
    $statement->bind_param('ii', $id, $customerId);
    $statement->execute();
    $onlinePayment = $statement->get_result()->fetch_assoc();
    if (!$onlinePayment) {
        http_response_code(404);
        exit('Receipt not found.');
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title><?php echo $isCustomer ? 'Your booking' : 'Receipt'; ?> — Bongabong View Hotel</title>
    <link rel="stylesheet" href="style.css?v=<?php echo filemtime(__DIR__ . '/style.css'); ?>">
    <?php if ($isCustomer) { ?><link rel="stylesheet" href="portals.css?v=<?php echo filemtime(__DIR__ . '/portals.css'); ?>"><?php } ?>
</head>
<body<?php if ($isCustomer) { ?> class="portal-body portal-guest-page portal-confirmation-page"<?php } ?>>

<?php if ($isCustomer) { render_navbar(); } else { ?><div class="no-print"><?php render_navbar(); ?></div><?php } ?>

<main class="<?php echo $isCustomer ? 'portal-page portal-confirmation-content' : 'receipt-page'; ?>" id="main-content">

    <?php if ($row == null) { ?>

        <div class="receipt">
            <span class="eyebrow">Guest receipt</span>
            <h1>Receipt not found</h1>
            <p class="center">The transaction could not be found.</p>
        </div>

        <div class="receipt-actions no-print">
            <?php if ($isCustomer) { ?>
            <a href="customer_home.php#our-rooms">Back to your stay</a>
            <?php } else { ?>
            <a href="transactions.php">Back to Transactions</a>
            <a href="index.php">Back to Dashboard</a>
            <?php } ?>
        </div>

    <?php } else { ?>

        <?php
            $nights = (int)$row["hours"];
            // Receipts reflect the amount charged when booked, even if room rates change.
            $extra_bed = (float)($row["extra_bed"] ?? 0);
            $food = (float)($row["food"] ?? 0);
            $damages = (float)($row["damages"] ?? 0);
            $room_total = (float)$row["total_amount"] - $extra_bed - $food - $damages;
            $booked_rate = $nights > 0 ? $room_total / $nights : $room_total;
            $bookingState = reservation_state($row);
            [$bookingHeading, $bookingMessage, $bookingIcon] = guest_confirmation_copy($bookingState);
        ?>

        <?php if ($isCustomer) { ?>
        <section class="portal-container portal-booking-confirmation" aria-labelledby="booking-confirmation-title">
            <div class="portal-confirmation-heading<?php echo in_array($bookingState, ['cancelled', 'no_show'], true) ? ' is-changed' : ''; ?>">
                <span class="portal-confirmation-mark" aria-hidden="true"><?php echo ui_icon($bookingIcon); ?></span>
                <p class="portal-eyebrow">Your Bongabong View reservation</p>
                <h1 id="booking-confirmation-title"><?php echo e($bookingHeading); ?></h1>
                <p class="portal-confirmation-message"><?php echo e($bookingMessage); ?></p>
                <div class="portal-confirmation-reference"><span>Reservation #<?php echo (int) $row['id']; ?></span><span><?php echo e(reservation_status($row)); ?></span></div>
            </div>
            <div class="portal-confirmation-card">
                <div class="portal-confirmation-room"><div><p class="portal-eyebrow">Your room</p><h2><?php echo e($row['room_name']); ?></h2><p><?php echo e($row['room_type']); ?> · <?php echo e($row['full_name']); ?></p></div><span class="portal-payment-recorded"><?php echo ui_icon('check'); ?><?php echo $onlinePayment ? 'Online payment recorded' : 'Contact the hotel for payment details'; ?></span></div>
                <dl class="portal-confirmation-dates"><div><dt>Arrival</dt><dd><?php echo e(date('M j, Y', strtotime($row['scheduled_check_in'] ?? $row['check_in']))); ?><small><?php echo e(date('g:i A', strtotime($row['scheduled_check_in'] ?? $row['check_in']))); ?></small></dd></div><div><dt>Departure</dt><dd><?php echo e(date('M j, Y', strtotime($row['scheduled_check_out'] ?? $row['check_out']))); ?><small><?php echo e(date('g:i A', strtotime($row['scheduled_check_out'] ?? $row['check_out']))); ?></small></dd></div><div><dt>Length of stay</dt><dd><?php echo $nights; ?> <?php echo $nights === 1 ? 'night' : 'nights'; ?></dd></div></dl>
                <div class="portal-confirmation-payment"><div><p>Amount paid online</p><strong><?php echo $onlinePayment ? money($onlinePayment['amount']) : 'Contact the hotel'; ?></strong><?php if ($onlinePayment && $onlinePayment['paid_at']) { ?><small>Recorded <?php echo e(date('M j, Y · g:i A', strtotime($onlinePayment['paid_at']))); ?></small><?php } ?></div><p>Your digital receipt is available in My bookings.<br>Keep your reservation number handy when contacting the hotel.</p></div>
                <?php if ($onlinePayment && abs((float) $row['total_amount'] - (float) $onlinePayment['amount']) >= 0.01) { ?><p class="portal-form-note">Current stay charges: <?php echo money($row['total_amount']); ?>. Additional charges are listed in your detailed receipt below.</p><?php } ?>
                <div class="portal-confirmation-actions"><a class="portal-button" href="my_bookings.php">My bookings <?php echo ui_icon('arrow-up'); ?></a><a class="portal-text-link" href="tel:09228125061">Contact the hotel <?php echo ui_icon('arrow-up'); ?></a><a class="portal-text-link" href="https://maps.app.goo.gl/5pKXwbYQhDFee1aq7" target="_blank" rel="noopener noreferrer">Get directions <?php echo ui_icon('arrow-up'); ?></a></div>
            </div>
        </section>
        <details class="portal-container portal-digital-receipt"><summary>View your detailed receipt <?php echo ui_icon('plus'); ?></summary>
        <?php } ?>

        <article class="receipt">
            <header class="receipt-header">
                <img src="puno.png" class="receipt-logo" alt="Bongabong View Hotel">
                <div>
                    <span class="eyebrow">Bongabong View Hotel</span>
                    <?php if ($isCustomer) { ?><h2>Your digital receipt.</h2><?php } else { ?><h1>Your stay, in detail.</h1><?php } ?>
                    <p>JP Rizal St. Bgy. Poblacion<br>Bongabong, Philippines · 0922 812 5061</p>
                </div>
            </header>

            <div class="receipt-meta">
                <p><b>Receipt No:</b> <?php echo (int)$row["id"]; ?></p>
                <p><b>Date:</b> <?php echo e($row["date_created"]); ?></p>
                <p><b>Status:</b> <?php echo e(reservation_status($row)); ?></p>
            </div>

            <div class="receipt-detail-grid">
                <section class="receipt-section">
                    <h2>Guest details</h2>
                    <p><b>Guest Name:</b> <?php echo e($row["full_name"]); ?></p>
                    <p><b>Contact Number:</b> <?php echo e($row["contact_number"]); ?></p>
                    <p><b>Address:</b> <?php echo e($row["address"]); ?></p>
                </section>
                <section class="receipt-section">
                    <h2>Stay details</h2>
                    <p><b>Room:</b> <?php echo e($row["room_name"]); ?></p>
                    <p><b>Room Type:</b> <?php echo e($row["room_type"]); ?></p>
                    <p><b>Rate:</b> <?php echo money($booked_rate); ?> / night</p>
                    <p><b>Number of Nights:</b> <?php echo $nights; ?></p>
                    <p><b>Scheduled Arrival:</b> <?php echo e($row['scheduled_check_in'] ?? $row['check_in']); ?></p>
                    <p><b>Scheduled Departure:</b> <?php echo e($row['scheduled_check_out'] ?? $row['check_out']); ?></p>
                    <?php if ($row['actual_check_in']) { ?><p><b>Checked In:</b> <?php echo e($row['actual_check_in']); ?></p><?php } ?>
                    <?php if ($row['actual_check_out']) { ?><p><b>Checked Out:</b> <?php echo e($row['actual_check_out']); ?></p><?php } ?>
                </section>
            </div>

            <section class="receipt-section receipt-charges">
            <h2>Payment summary</h2>
            <p class="receipt-line"><b>Room Total:</b> <span><?php echo money($room_total); ?></span></p>
            <?php if ($extra_bed != 0) { ?>
                <p class="receipt-line"><b>Extra Bed:</b> <span><?php echo money($extra_bed); ?></span></p>
            <?php } ?>
            <?php if ($food != 0) { ?>
                <p class="receipt-line"><b>Food:</b> <span><?php echo money($food); ?></span></p>
            <?php } ?>
            <?php if ($damages != 0) { ?>
                <p class="receipt-line"><b>Damages:</b> <span><?php echo money($damages); ?></span></p>
            <?php } ?>

            <h3 class="receipt-total"><?php echo $isCustomer ? 'Total stay charges: ' : 'Total Amount: '; ?><?php echo money($row["total_amount"]); ?></h3>
            <p><b>Payment Method:</b> <?php echo e($row["payment_method"]); ?></p>
            </section>

            <p class="receipt-thanks">Thank you for making us part of your journey.</p>
        </article>
        <?php if ($isCustomer) { ?></details><?php } ?>

        <?php if (!$isCustomer) { ?>
        <div class="receipt-actions no-print">
            <button type="button" onclick="window.print()">Print receipt <span aria-hidden="true">↗</span></button>
            <a href="transactions.php">Back to Transactions</a>
            <a href="index.php">Back to Dashboard</a>
        </div>
        <?php } ?>

    <?php } ?>

    <?php if ($isCustomer && $row) render_guest_information(); ?>

</main>

<?php if ($isCustomer) render_footer(); ?>
</body>
</html>
