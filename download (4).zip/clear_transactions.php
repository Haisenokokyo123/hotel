<?php
require_once __DIR__ . '/config.php';
require_staff();
if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    header('Location: transactions.php');
    exit;
}
require_csrf();
$conn = db_connect();
$conn->query("UPDATE reservations r LEFT JOIN reservation_states s ON s.reservation_id = r.id
    SET r.is_archived = 1 WHERE r.check_out <= NOW() AND r.is_archived = 0
    AND COALESCE(s.state, 'checked_out') = 'checked_out'");
$redirect = $_POST['redirect'] ?? '';
$allowed = ['index.php?clear=success', 'index.php?clear=success#transactions', 'transactions.php?clear=success'];
if (!in_array($redirect, $allowed, true)) {
    $redirect = 'transactions.php?clear=success';
}
header('Location: ' . $redirect);
exit;
