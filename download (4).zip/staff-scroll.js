// Decorative effects follow native scrolling; operational content stays stationary.
(() => {
  const body = document.body;
  const hero = document.querySelector('.staff-hero');
  if (!body.classList.contains('staff-page') || !hero || !window.matchMedia) return;
  const preference = window.matchMedia('(prefers-reduced-motion: reduce)');
  const toggle = document.querySelector('[data-staff-motion-toggle]');
  const photos = [...hero.querySelectorAll('.staff-hero-image')];
  let userPaused = false;
  try { userPaused = localStorage.getItem('hoteru.staff.motion') === 'off'; } catch (_) {}
  let enabled = false;
  let frame = 0;
  let previousHeroProgress = -1;
  let previousPageProgress = -1;
  const clamp = (value) => Math.max(0, Math.min(1, value));
  const draw = () => {
    frame = 0;
    if (!enabled || document.hidden) return;
    // Read geometry together before writing styles. No element heights, scroll
    // positions, or input events are changed by this handler.
    const bounds = hero.getBoundingClientRect();
    const progress = clamp(-bounds.top / Math.max(1, bounds.height));
    const pageProgress = clamp(window.scrollY / Math.max(1, document.documentElement.scrollHeight - window.innerHeight));
    if (progress !== previousHeroProgress) {
      hero.style.setProperty('--scroll-line', progress.toFixed(4));
      photos.forEach((photo, index) => {
        photo.style.opacity = index === 0 ? '1' : clamp(progress * (photos.length - 1) - index + 1).toFixed(4);
      });
      previousHeroProgress = progress;
    }
    if (pageProgress !== previousPageProgress) {
      body.style.setProperty('--page-progress', pageProgress.toFixed(4));
      previousPageProgress = pageProgress;
    }
  };
  const schedule = () => {
    if (enabled && !document.hidden && !frame) frame = requestAnimationFrame(draw);
  };
  const applyPreference = () => {
    enabled = !preference.matches && !userPaused;
    if (frame) cancelAnimationFrame(frame);
    frame = 0;
    previousHeroProgress = previousPageProgress = -1;
    body.classList.toggle('staff-motion-paused', !enabled);
    document.documentElement.classList.toggle('staff-motion-paused', !enabled);
    body.classList.toggle('staff-scroll-ready', enabled);
    if (toggle) {
      toggle.hidden = false;
      toggle.disabled = preference.matches;
      toggle.setAttribute('aria-pressed', String(enabled));
      const label = toggle.querySelector('[data-motion-label]');
      if (label) label.textContent = preference.matches ? 'Reduced motion' : enabled ? 'Motion on' : 'Motion off';
    }
    if (!enabled) {
      hero.style.removeProperty('--scroll-line');
      photos.forEach((photo, index) => { photo.style.opacity = index === 0 ? '1' : '0'; });
      body.style.removeProperty('--page-progress');
    } else schedule();
    window.dispatchEvent(new CustomEvent('staff-motion-change'));
  };
  toggle?.addEventListener('click', () => {
    userPaused = !userPaused;
    try { localStorage.setItem('hoteru.staff.motion', userPaused ? 'off' : 'on'); } catch (_) {}
    applyPreference();
  });
  if (preference.addEventListener) preference.addEventListener('change', applyPreference);
  else if (preference.addListener) preference.addListener(applyPreference);
  window.addEventListener('scroll', schedule, {passive: true});
  window.addEventListener('resize', schedule, {passive: true});
  window.addEventListener('pageshow', schedule);
  document.addEventListener('visibilitychange', () => {
    if (document.hidden) {
      if (frame) cancelAnimationFrame(frame);
      frame = 0;
    } else schedule();
  });
  applyPreference();
})();
