(() => {
  const money = new Intl.NumberFormat('en-PH', {style: 'currency', currency: 'PHP'});
  const day = 86400000;
  const dateValue = (value) => {
    if (!/^\d{4}-\d{2}-\d{2}$/.test(value)) return NaN;
    const [year, month, date] = value.split('-').map(Number);
    const time = Date.UTC(year, month - 1, date);
    return new Date(time).toISOString().slice(0, 10) === value ? time : NaN;
  };

  document.querySelectorAll('[data-date-search], [data-booking-form]').forEach((form) => {
    form.noValidate = true;
    const booking = form.hasAttribute('data-booking-form');
    const arrival = form.elements.arrival_date;
    const departure = form.elements.departure_date;
    const submit = form.querySelector('button[type="submit"]');
    const status = form.querySelector('[data-form-availability]');
    const note = form.querySelector('[data-checkout-note]');
    const rate = Number(form.dataset.rate) || 0;
    let available = form.dataset.initialAvailable === 'true';
    let attempted = false;
    let checking = false;
    let timer;
    let request;
    let revision = 0;
    const showError = (field, message) => {
      const input = form.elements[field];
      const error = form.querySelector(`[data-field-error="${field}"]`);
      if (!input || !error) return;
      error.textContent = message;
      error.hidden = !message;
      if (message) input.setAttribute('aria-invalid', 'true');
      else input.removeAttribute('aria-invalid');
    };
    const dateErrors = () => {
      const errors = {};
      const start = dateValue(arrival.value);
      const end = dateValue(departure.value);
      if (!Number.isFinite(start)) errors.arrival_date = 'Choose a valid arrival date.';
      else if (arrival.value < arrival.min) errors.arrival_date = 'Arrival must be today or later.';
      if (!Number.isFinite(end)) errors.departure_date = 'Choose a valid departure date.';
      else if (Number.isFinite(start) && end <= start) errors.departure_date = 'Departure must be after arrival.';
      else if (Number.isFinite(start) && (end - start) / day > 365) errors.departure_date = 'Choose a stay of up to 365 nights.';
      return errors;
    };
    const validateDates = () => {
      const errors = dateErrors();
      showError('arrival_date', errors.arrival_date || '');
      showError('departure_date', errors.departure_date || '');
      return Object.keys(errors).length === 0;
    };
    const contactError = (field) => {
      const value = form.elements[field].value.trim();
      if (!value) return {full_name:'Enter your full name.', contact_number:'Enter your contact number.', address:'Enter your address.'}[field];
      if (field === 'contact_number' && !/^[0-9]+$/.test(value)) return 'Enter numbers only for your contact number.';
      return '';
    };
    const updateSummary = () => {
      if (!booking) return;
      const valid = Object.keys(dateErrors()).length === 0;
      const nights = valid ? Math.round((dateValue(departure.value) - dateValue(arrival.value)) / day) : 0;
      form.querySelector('[data-nights-display]').textContent = String(nights);
      form.querySelector('[data-room-charge]').textContent = money.format(rate * nights);
      form.querySelector('[data-total-display]').textContent = money.format(rate * nights);
      submit.disabled = !valid || !available || checking;
    };
    const checkAvailability = async (version) => {
      request = new AbortController();
      const controller = request;
      const timeout = window.setTimeout(() => controller.abort(), 15000);
      try {
        const query = new URLSearchParams({room_id:form.elements.room_id.value, arrival_date:arrival.value, departure_date:departure.value});
        const response = await fetch(`guest_availability.php?${query}`, {credentials:'same-origin', cache:'no-store', signal:controller.signal});
        const result = await response.json();
        if (version !== revision) return;
        available = response.ok && result.available === true;
        status.textContent = result.message || 'Availability could not be checked. Please try again.';
        status.classList.toggle('is-unavailable', !available);
        note.textContent = available ? 'Review your dates and details before continuing.' : 'Change your dates or check availability again.';
      } catch (_) {
        if (version !== revision) return;
        available = false;
        status.textContent = 'Availability could not be checked. Please try again.';
        status.classList.add('is-unavailable');
        note.textContent = 'Check availability again before continuing.';
      } finally {
        window.clearTimeout(timeout);
        if (version === revision) {
          checking = false;
          status.removeAttribute('aria-busy');
          updateSummary();
        }
      }
    };
    const datesChanged = () => {
      window.clearTimeout(timer);
      request?.abort();
      revision++;
      const valid = validateDates();
      if (!booking) {
        const result = document.querySelector('.portal-availability-result');
        if (result) result.textContent = 'Dates changed. Check availability to update the room results.';
        document.querySelectorAll('.portal-room-reserve').forEach((button) => { button.disabled = true; });
        document.querySelectorAll('.portal-room-availability').forEach((label) => {
          label.textContent = 'Check availability for your new dates';
          label.classList.remove('is-available', 'is-unavailable');
        });
        document.querySelectorAll('.portal-room-stay-price').forEach((price) => { price.hidden = true; });
      }
      if (booking) {
        available = false;
        checking = valid;
        status.textContent = valid ? 'Checking availability for your dates…' : 'Check the highlighted dates.';
        status.setAttribute('aria-busy', valid ? 'true' : 'false');
        note.textContent = valid ? 'Checking room availability…' : 'Choose valid dates before continuing.';
        if (valid) {
          const version = revision;
          timer = window.setTimeout(() => checkAvailability(version), 250);
        }
        updateSummary();
      }
    };
    [arrival, departure].forEach((input) => {
      input.addEventListener('input', datesChanged);
      input.addEventListener('change', datesChanged);
      input.addEventListener('blur', validateDates);
    });
    if (booking) {
      form.querySelector('[data-availability-retry]')?.addEventListener('click', datesChanged);
      ['full_name', 'contact_number', 'address'].forEach((field) => {
        const input = form.elements[field];
        input.addEventListener('blur', () => showError(field, contactError(field)));
        input.addEventListener('input', () => {
          if (field === 'contact_number') {
            const before = input.value;
            const cursor = input.selectionStart;
            input.value = before.replace(/[^0-9]/g, '');
            if (before !== input.value) {
              if (cursor !== null) {
                const position = before.slice(0, cursor).replace(/[^0-9]/g, '').length;
                input.setSelectionRange(position, position);
              }
              showError(field, 'Only numbers are allowed. Other characters were removed.');
              return;
            }
          }
          if (attempted || input.hasAttribute('aria-invalid')) showError(field, contactError(field));
        });
        if (field === 'contact_number') input.addEventListener('beforeinput', (event) => {
          if (event.inputType === 'insertText' && event.data && /[^0-9]/.test(event.data)) {
            event.preventDefault();
            showError(field, 'Use numbers only for your contact number.');
          }
        });
      });
      updateSummary();
    }
    form.addEventListener('submit', (event) => {
      attempted = true;
      let valid = validateDates();
      if (booking) ['full_name', 'contact_number', 'address'].forEach((field) => {
        const error = contactError(field);
        showError(field, error);
        if (error) valid = false;
      });
      if (!valid || (booking && (!available || checking))) {
        event.preventDefault();
        form.querySelector('[aria-invalid="true"]')?.focus();
        return;
      }
      submit.disabled = true;
      submit.textContent = booking ? 'Opening secure checkout…' : 'Checking availability…';
    });
  });
  window.addEventListener('pageshow', (event) => {
    if (event.persisted) window.location.reload();
  });
})();
