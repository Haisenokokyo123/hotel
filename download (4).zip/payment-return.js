(() => {
  const verification = document.getElementById('payment-verification');
  if (!verification) return;
  const title = document.getElementById('payment-title');
  const message = document.getElementById('payment-message');
  const action = document.getElementById('payment-action');
  const deadline = Date.now() + 120000;
  const stop = (heading, explanation) => {
    title.textContent = heading;
    message.textContent = explanation;
    action.href = 'gcash_return.php?token=' + encodeURIComponent(verification.dataset.token);
    action.textContent = 'Check payment again';
  };
  const check = async () => {
    const controller = new AbortController();
    const timeout = window.setTimeout(() => controller.abort(), 25000);
    try {
      const response = await fetch('gcash_status.php', {
        method: 'POST',
        cache: 'no-store',
        credentials: 'same-origin',
        signal: controller.signal,
        body: new URLSearchParams({token: verification.dataset.token, csrf_token: verification.dataset.csrf}),
      });
      const data = await response.json();
      if (response.ok && data.status === 'paid' && /^receipt\.php\?id=\d+$/.test(data.receipt_url)) {
        title.textContent = 'Payment confirmed.';
        message.textContent = 'Your room is booked. Opening your booking confirmation…';
        action.href = data.receipt_url;
        action.textContent = 'View booking confirmation';
        window.location.replace(data.receipt_url);
        return;
      }
      if (['authentication_required', 'session_expired'].includes(data.status)) {
        stop('Your session needs refreshing.', 'Sign in again if needed, then reopen this payment page to check your booking. Please do not pay again if your wallet was charged.');
        return;
      }
      if (data.status === 'review_required') {
        stop('Your payment needs hotel assistance.', 'We could not automatically confirm the room for this payment. Please call the front desk with your payment reference. Do not pay again.');
        return;
      }
      if (['failed', 'expired', 'cancelled', 'missing', 'invalid'].includes(data.status)) {
        stop('Your booking is not confirmed.', 'If your wallet was charged, please contact the front desk with your payment reference before making another payment. You can check this payment again below.');
        return;
      }
      message.textContent = data.status === 'verification_unavailable'
        ? 'We cannot check payment right now. We will retry shortly. If your wallet was charged, please do not pay again.'
        : 'Payment confirmation is still pending. We will check again shortly.';
    } catch (_) {
      message.textContent = 'The payment check could not connect. We will retry shortly. Please do not pay again if your wallet was charged.';
    } finally {
      window.clearTimeout(timeout);
    }
    if (Date.now() >= deadline) {
      stop('Confirmation is taking longer than expected.', 'You can check again below or call the front desk with your payment reference. Please do not pay again if your wallet was charged.');
      return;
    }
    window.setTimeout(check, 5000);
  };
  check();
})();
