<?php
require_once __DIR__ . '/config.php';
require_once __DIR__ . '/gcash.php';
require_once __DIR__ . '/guest_booking.php';
start_app_session();
header('Content-Type: application/json; charset=utf-8');
header('Cache-Control: private, no-store');
if (($_SESSION['role'] ?? '') !== 'customer') {
    http_response_code(401);
    exit(json_encode(['message' => 'Sign in again to check room availability.']));
}
$roomId = filter_var($_GET['room_id'] ?? null, FILTER_VALIDATE_INT, ['options' => ['min_range' => 1]]) ?: 0;
$arrival = is_string($_GET['arrival_date'] ?? null) ? $_GET['arrival_date'] : '';
$departure = is_string($_GET['departure_date'] ?? null) ? $_GET['departure_date'] : '';
$errors = guest_date_errors($arrival, $departure);
if (!$roomId || $errors) {
    http_response_code(422);
    exit(json_encode(['message' => 'Choose valid stay dates.', 'errors' => $errors]));
}
try {
    $conn = db_connect();
    $statement = $conn->prepare('SELECT is_active FROM rooms WHERE id = ?');
    $statement->bind_param('i', $roomId);
    $statement->execute();
    $room = $statement->get_result()->fetch_assoc();
    $available = $room && (int) $room['is_active'] === 1 && guest_room_available($conn, $roomId, guest_stay_dates($arrival, $departure));
    echo json_encode(['available' => (bool) $available, 'message' => $available ? 'Available for your dates.' : 'Unavailable for your dates. Choose different dates or another room.']);
} catch (Throwable $error) {
    error_log('Guest availability check failed: ' . $error->getMessage());
    http_response_code(503);
    echo json_encode(['message' => 'Availability could not be checked. Please try again.']);
}
