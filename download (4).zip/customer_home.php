<?php
require_once __DIR__ . '/config.php';
require_once __DIR__ . '/gcash.php';
require_once __DIR__ . '/guest_booking.php';
require_once __DIR__ . '/guest_content.php';
require_role('customer');

$conn = db_connect();
$rooms = mysqli_query($conn, 'SELECT rooms.*, details.guest_capacity, details.bed_setup, details.amenities FROM rooms LEFT JOIN room_guest_details details ON details.room_id = rooms.id WHERE is_active=1 ORDER BY room_name');
$roomCount = mysqli_num_rows($rooms);
$guestBookingError = $_SESSION['guest_booking_error'] ?? '';
$guestBookingOld = $_SESSION['guest_booking_old'] ?? [];
$guestFieldErrors = $_SESSION['guest_booking_field_errors'] ?? [];
$guestBookingSuccess = $_SESSION['guest_booking_success'] ?? '';
$failedGuestBookingRoomId = filter_var($_GET['room_id'] ?? null, FILTER_VALIDATE_INT, ['options' => ['min_range' => 1]]) ?: 0;
unset($_SESSION['guest_booking_error'], $_SESSION['guest_booking_old'], $_SESSION['guest_booking_success'], $_SESSION['guest_booking_field_errors']);
$arrivalDate = $guestBookingOld['arrival_date'] ?? (is_string($_GET['arrival_date'] ?? null) ? $_GET['arrival_date'] : date('Y-m-d'));
$departureDate = $guestBookingOld['departure_date'] ?? (is_string($_GET['departure_date'] ?? null) ? $_GET['departure_date'] : date('Y-m-d', strtotime('+1 day')));
$hasSelectedDates = isset($_GET['arrival_date']) || isset($_GET['departure_date']) || !empty($guestBookingOld);
$dateErrors = $hasSelectedDates ? guest_date_errors($arrivalDate, $departureDate) : [];
$selectedStay = $hasSelectedDates && !$dateErrors ? guest_stay_dates($arrivalDate, $departureDate) : null;
$previewNights = $selectedStay['nights'] ?? 0;
$availableRoomCount = 0;
$roomListings = [];
while ($room = mysqli_fetch_assoc($rooms)) {
    $room['guest_available'] = $selectedStay ? guest_room_available($conn, (int) $room['id'], $selectedStay) : null;
    if ($room['guest_available']) $availableRoomCount++;
    $roomListings[] = $room;
}
$heroPhoto = hotel_photo('pic2') ?: 'hoteru.png';
$propertyPhotos = [];
foreach (['pic1', 'pic2', 'pic3', 'pic4', 'pic5', 'pic6'] as $photoName) {
    $photoPath = hotel_photo($photoName);
    if ($photoPath !== null) {
        $propertyPhotos[] = $photoPath;
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Your Stay — Bongabong View Hotel</title>
    <link rel="stylesheet" href="style.css?v=<?php echo filemtime(__DIR__ . '/style.css'); ?>">
    <link rel="stylesheet" href="portals.css?v=<?php echo filemtime(__DIR__ . '/portals.css'); ?>">
    <script src="guest-forms.js?v=<?php echo filemtime(__DIR__ . '/guest-forms.js'); ?>" defer></script>
</head>
<body class="portal-body portal-guest-page">
<?php render_navbar(); ?>

<main class="portal-page portal-guest-content" id="main-content">
    <section class="portal-guest-hero" aria-labelledby="guest-title">
        <div class="portal-hero-photo" aria-hidden="true">
            <img src="<?php echo e($heroPhoto); ?>" alt="" fetchpriority="high">
        </div>
        <div class="portal-container portal-hero-inner">
        <div class="portal-hero-copy" data-reveal>
            <p class="portal-eyebrow">Bongabong View Hotel · Guest portal</p>
            <h1 id="guest-title">A warm welcome.<br>A stay to <em>remember.</em></h1>
            <p class="portal-intro">Find your place in Bongabong. Choose your dates, find your room, and book your next stay online.</p>
            <div class="portal-hero-actions">
                <a class="portal-button" href="#our-rooms">Explore our rooms <?php echo ui_icon('arrow-up'); ?></a>
                <a class="portal-hero-contact" href="#plan-your-stay">Plan your visit <?php echo ui_icon('arrow-up'); ?></a>
            </div>
            <div class="portal-hero-location">
                <span class="portal-location-mark" aria-hidden="true">✧</span>
                <span>Bongabong, Oriental Mindoro<br><small>Your next stay starts here.</small></span>
            </div>
        </div>
        <p class="portal-hero-note">Come on in.<br><em>Make yourself at home.</em></p>
        </div>
    </section>

    <section class="portal-container portal-welcome" aria-label="Welcome and reservations" data-reveal>
        <div>
            <p class="portal-eyebrow">It’s good to see you</p>
            <h2>Welcome, <?php echo e($_SESSION['name']); ?>.</h2>
        </div>
        <p>Choose your dates, select a room, and book online. Your reservation is confirmed after payment.</p>
        <a class="portal-text-link" href="my_bookings.php">My bookings <?php echo ui_icon('arrow-up'); ?></a>
    </section>

    <section class="portal-location-section" aria-labelledby="location-title">
        <div class="portal-container portal-location-heading">
            <div>
                <p class="portal-eyebrow">We are here</p>
                <h2 id="location-title">Find us in <em>Bongabong.</em></h2>
                <p>JP Rizal St., Bgy. Poblacion, Bongabong, Oriental Mindoro</p>
            </div>
            <a class="portal-text-link" href="https://maps.app.goo.gl/5pKXwbYQhDFee1aq7" target="_blank" rel="noopener noreferrer">Open in Google Maps <?php echo ui_icon('arrow-up'); ?></a>
        </div>
        <!-- Keep the map setup in this page so no separate map files need uploading. -->
        <iframe class="portal-location-map" id="hotel-location-map"
            title="Map showing Bongabong View Hotel on JP Rizal Street. Use the plus and minus buttons to zoom."
            srcdoc="<?php echo e(<<<'HOTEL_MAP'
<!doctype html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="stylesheet" href="https://unpkg.com/leaflet@1.9.4/dist/leaflet.css" integrity="sha256-p4NxAoJBhIIN+hmNHrzRCf9tD/miZyoHS5obTRR9BMY=" crossorigin="anonymous">
    <style>
        html, body, #map { width: 100%; height: 100%; margin: 0; }
        #map { background: #e4e8dd; }
        .fallback { padding: 32px; text-align: center; font: 16px/1.8 Arial, sans-serif; color: #183d34; }
        .fallback a { color: inherit; }
        .leaflet-control-zoom a { width: 42px; height: 42px; line-height: 42px; color: #183d34; }
        .hotel-pin { background: transparent; border: 0; }
        .hotel-label { color: #183d34; font: 600 14px/1.5 Arial, sans-serif; text-align: center; }
    </style>
</head>
<body>
    <div id="map" role="region" aria-label="Hotel location. Zoom using the plus and minus buttons.">
        <div class="fallback">Bongabong View Hotel · JP Rizal Street<br><a href="https://maps.app.goo.gl/5pKXwbYQhDFee1aq7" target="_blank" rel="noopener noreferrer">View our location in Google Maps</a></div>
    </div>
    <script src="https://unpkg.com/leaflet@1.9.4/dist/leaflet.js" integrity="sha256-20nQCchB9co0qIjJZRGuk2/Z9VM+kNiyxNV1lvTlZBo=" crossorigin="anonymous"></script>
    <script>
        if (window.L) {
            document.getElementById('map').replaceChildren();
            const location = [12.7465997, 121.4866604];
            const map = L.map('map', {
                scrollWheelZoom: false,
                doubleClickZoom: false,
                touchZoom: false,
                boxZoom: false,
                keyboard: false,
                zoomControl: false
            }).setView(location, 16);
            L.control.zoom({ position: 'topright' }).addTo(map);
            L.tileLayer('https://tile.openstreetmap.org/{z}/{x}/{y}.png', {
                maxZoom: 19,
                attribution: '&copy; <a href="https://www.openstreetmap.org/copyright" target="_blank" rel="noopener noreferrer">OpenStreetMap</a> contributors'
            }).addTo(map);
            const pin = L.divIcon({
                className: 'hotel-pin', iconSize: [32, 42], iconAnchor: [16, 42], tooltipAnchor: [0, -42],
                html: '<svg xmlns="http://www.w3.org/2000/svg" width="32" height="42" viewBox="0 0 32 42" aria-hidden="true"><path d="M16 1C7.7 1 1 7.7 1 16c0 11 15 25 15 25s15-14 15-25C31 7.7 24.3 1 16 1Z" fill="#183d34" stroke="#b28a45" stroke-width="2"/><circle cx="16" cy="16" r="6" fill="#fff"/></svg>'
            });
            L.marker(location, { icon: pin, title: 'Bongabong View Hotel', alt: 'Hotel location' })
                .addTo(map).bindTooltip('We are here!<br>Bongabong View Hotel', {
                    permanent: true, direction: 'top', className: 'hotel-label'
                });
        }
    </script>
</body>
</html>
HOTEL_MAP
            ); ?>"
            width="100%" height="500" loading="lazy" referrerpolicy="strict-origin-when-cross-origin"></iframe>
    </section>

    <section class="portal-container portal-rooms-section" id="our-rooms" aria-labelledby="rooms-title">
        <div class="portal-section-heading" data-reveal>
            <div>
                <p class="portal-eyebrow">Find your room</p>
                <h2 id="rooms-title">Make room for <em>your stay.</em></h2>
            </div>
            <p><?php echo $roomCount; ?> <?php echo $roomCount === 1 ? 'room' : 'rooms'; ?> to explore<br><span>Find availability for your stay</span></p>
        </div>
        <form class="portal-date-search" id="choose-stay-dates" action="customer_home.php#our-rooms" method="GET" data-date-search>
            <div class="portal-date-search-intro"><h3>When would you like to stay?</h3><p>Select your dates to check all rooms.</p></div>
            <div class="portal-field"><label>Arrival date<input type="date" name="arrival_date" min="<?php echo date('Y-m-d'); ?>" value="<?php echo e($arrivalDate); ?>" required<?php echo guest_error_attributes($dateErrors, 'arrival_date', 'search'); ?>></label><?php guest_field_error($dateErrors, 'arrival_date', 'search'); ?></div>
            <div class="portal-field"><label>Departure date<input type="date" name="departure_date" min="<?php echo date('Y-m-d', strtotime('+1 day')); ?>" value="<?php echo e($departureDate); ?>" required<?php echo guest_error_attributes($dateErrors, 'departure_date', 'search'); ?>></label><?php guest_field_error($dateErrors, 'departure_date', 'search'); ?></div>
            <button class="portal-button" type="submit">Check availability <?php echo ui_icon('arrow-up'); ?></button>
        </form>
        <p class="portal-availability-result" role="status"><?php echo $selectedStay ? e($availableRoomCount . ' ' . ($availableRoomCount === 1 ? 'room available' : 'rooms available') . ' · ' . date('M j, Y', strtotime($arrivalDate)) . ' – ' . date('M j, Y', strtotime($departureDate)) . ' · ' . $previewNights . ' ' . ($previewNights === 1 ? 'night' : 'nights')) : 'Choose your dates above to see room availability.'; ?></p>
        <?php if ($guestBookingSuccess !== '') { ?>
            <div class="portal-booking-message portal-booking-message--success" role="status"><?php echo e($guestBookingSuccess); ?></div>
        <?php } ?>
        <?php if ($guestBookingError !== '') { ?>
            <div class="portal-booking-message portal-booking-message--error" role="alert"><?php echo e($guestBookingError); ?></div>
        <?php } ?>
        <?php if ($roomCount === 0) { ?>
            <div class="portal-empty">
                <h3>Let us help you find your room.</h3>
                <p>Room listings are being updated. Call our front desk for current availability and rates.</p>
                <a class="portal-button" href="tel:09228125061">Contact the front desk <?php echo ui_icon('arrow-up'); ?></a>
            </div>
        <?php } else { ?>
            <div class="portal-room-grid">
            <?php foreach ($roomListings as $room) { ?>
                <?php
                    $facts = guest_room_facts($room);
                    $fieldErrors = $failedGuestBookingRoomId === (int) $room['id'] ? $guestFieldErrors : [];
                    $errorPrefix = 'booking-' . (int) $room['id'];
                ?>
                <article class="portal-room-card" data-reveal>
                    <?php render_room_visual($room, 'portal-room-visual'); ?>
                    <div class="portal-room-content">
                        <p class="portal-eyebrow"><?php echo e($room['room_type']); ?></p>
                        <h3><?php echo e($room['room_name']); ?></h3>
                        <dl class="portal-room-facts">
                            <div><dt>Guests</dt><dd><?php echo $facts['capacity'] ? 'Up to ' . $facts['capacity'] : 'Ask the hotel for capacity'; ?></dd></div>
                            <div><dt>Beds</dt><dd><?php echo e($facts['beds'] ?: 'Ask the hotel for bed setup'); ?></dd></div>
                        </dl>
                        <?php if ($facts['amenities']) { ?><ul class="portal-room-amenities" aria-label="Room amenities"><?php foreach ($facts['amenities'] as $amenity) { ?><li><?php echo e($amenity); ?></li><?php } ?></ul><?php } ?>
                        <p class="portal-room-availability <?php echo $room['guest_available'] === true ? 'is-available' : ($room['guest_available'] === false ? 'is-unavailable' : ''); ?>"><?php echo $room['guest_available'] === true ? 'Available for your dates' : ($room['guest_available'] === false ? 'Unavailable for your dates' : 'Select dates to check availability'); ?></p>
                        <div class="portal-room-bottom">
                            <p class="portal-room-rate"><?php echo money($room['room_rate']); ?><span>per night</span></p>
                            <?php if ($room['guest_available'] === true) { ?>
                                <button class="portal-button portal-room-reserve" type="button" data-booking-open="book-room-<?php echo (int) $room['id']; ?>" aria-haspopup="dialog" aria-controls="book-room-<?php echo (int) $room['id']; ?>">Reserve room <?php echo ui_icon('arrow-up'); ?></button>
                            <?php } else { ?>
                                <a class="portal-room-inquire" href="#choose-stay-dates"><?php echo $selectedStay ? 'Change dates' : 'Choose dates'; ?> <?php echo ui_icon('arrow-up'); ?></a>
                            <?php } ?>
                        </div>
                        <?php if ($selectedStay) { ?><p class="portal-room-stay-price"><?php echo money($room['room_rate'] * $previewNights); ?> for <?php echo $previewNights; ?> <?php echo $previewNights === 1 ? 'night' : 'nights'; ?></p><?php } ?>
                    </div>
                </article>
                <dialog class="portal-booking-form portal-booking-dialog" id="book-room-<?php echo (int) $room['id']; ?>" aria-labelledby="booking-title-<?php echo (int) $room['id']; ?>"<?php echo $failedGuestBookingRoomId === (int) $room['id'] ? ' data-booking-reopen' : ''; ?>>
                    <div class="portal-booking-dialog-heading">
                        <div>
                            <p class="portal-eyebrow">Your next stay</p>
                            <h3 id="booking-title-<?php echo (int) $room['id']; ?>">Reserve <?php echo e($room['room_name']); ?></h3>
                        </div>
                        <button class="portal-booking-close" type="button" data-booking-close aria-label="Close reservation form">&times;</button>
                    </div>
                    <?php if ($failedGuestBookingRoomId === (int) $room['id'] && $guestBookingError !== '') { ?>
                        <div class="portal-booking-message portal-booking-message--error" role="alert"><?php echo e($guestBookingError); ?></div>
                    <?php } ?>
                    <form action="save_guest_booking.php" method="POST" data-booking-form data-rate="<?php echo e($room['room_rate']); ?>" data-initial-available="<?php echo $room['guest_available'] ? 'true' : 'false'; ?>">
                        <input type="hidden" name="csrf_token" value="<?php echo e(csrf_token()); ?>">
                        <input type="hidden" name="room_id" value="<?php echo (int) $room['id']; ?>">
                        <input type="hidden" name="payment_method" value="Online Payment">
                        <div class="portal-booking-main">
                        <h4>Your stay dates</h4>
                        <div class="portal-booking-fields">
                            <div class="portal-field"><label>Arrival date<input type="date" name="arrival_date" min="<?php echo date('Y-m-d'); ?>" value="<?php echo e($arrivalDate); ?>" required<?php echo guest_error_attributes($fieldErrors, 'arrival_date', $errorPrefix); ?>></label><?php guest_field_error($fieldErrors, 'arrival_date', $errorPrefix); ?></div>
                            <div class="portal-field"><label>Departure date<input type="date" name="departure_date" min="<?php echo date('Y-m-d', strtotime('+1 day')); ?>" value="<?php echo e($departureDate); ?>" required<?php echo guest_error_attributes($fieldErrors, 'departure_date', $errorPrefix); ?>></label><?php guest_field_error($fieldErrors, 'departure_date', $errorPrefix); ?></div>
                        </div>
                        <p class="portal-form-note">Check-in from 2:00 PM · Check-out by 12:00 noon.</p>
                        <p class="portal-form-availability" data-form-availability role="status"><?php echo $room['guest_available'] ? 'Available for your dates.' : 'Choose valid dates to check availability.'; ?></p>
                        <button class="portal-availability-retry" type="button" data-availability-retry>Check these dates again</button>
                        <h4>Your contact details</h4>
                        <div class="portal-field"><label>Full name<input type="text" name="full_name" autocomplete="name" maxlength="100" value="<?php echo e($guestBookingOld['full_name'] ?? $_SESSION['name']); ?>" required<?php echo guest_error_attributes($fieldErrors, 'full_name', $errorPrefix); ?>></label><?php guest_field_error($fieldErrors, 'full_name', $errorPrefix); ?></div>
                        <div class="portal-field"><label>Contact number<input type="tel" name="contact_number" autocomplete="tel" inputmode="numeric" pattern="[0-9]+" title="Enter numbers only." data-digits-only maxlength="50" value="<?php echo e($guestBookingOld['contact_number'] ?? ''); ?>" required<?php echo guest_error_attributes($fieldErrors, 'contact_number', $errorPrefix); ?>></label><?php guest_field_error($fieldErrors, 'contact_number', $errorPrefix); ?><small class="portal-form-note">Numbers only, including the leading 0.</small></div>
                        <div class="portal-field"><label>Address<textarea name="address" autocomplete="street-address" maxlength="65535" required<?php echo guest_error_attributes($fieldErrors, 'address', $errorPrefix); ?>><?php echo e($guestBookingOld['address'] ?? ''); ?></textarea></label><?php guest_field_error($fieldErrors, 'address', $errorPrefix); ?></div>
                        <div class="portal-payment-info"><strong>Pay online with QRPh</strong><p>Scan the secure checkout code with GCash or another compatible wallet. Your room is booked after payment is confirmed.</p></div>
                        </div>
                        <aside class="portal-booking-aside">
                        <section class="portal-stay-summary" aria-label="Stay summary">
                            <h4>Stay summary</h4>
                            <p><span>Nights</span><strong data-nights-display><?php echo $previewNights; ?></strong></p>
                            <p><span>Rate per night</span><strong data-rate-display><?php echo money($room['room_rate']); ?></strong></p>
                            <p><span>Room charge</span><strong data-room-charge><?php echo money($room['room_rate'] * $previewNights); ?></strong></p>
                        </section>
                        <div class="portal-booking-checkout">
                            <p><span>Total amount</span><strong data-total-display><?php echo money($room['room_rate'] * $previewNights); ?></strong></p>
                            <button class="portal-button" type="submit">Continue to payment <?php echo ui_icon('arrow-up'); ?></button>
                            <small class="portal-form-note" data-checkout-note>Review your dates and details before continuing.</small>
                        </div>
                        </aside>
                    </form>
                </dialog>
            <?php } ?>
            </div>
        <?php } ?>
    </section>

    <?php render_guest_information(); ?>

    <?php if ($propertyPhotos) { ?>
    <section class="portal-property-section" aria-labelledby="property-title">
        <div class="portal-container">
            <div class="portal-section-heading" data-reveal>
                <div>
                    <p class="portal-eyebrow">A little closer</p>
                    <h2 id="property-title">A glimpse of <em>Bongabong View.</em></h2>
                </div>
                <p>Get to know the place<br><span>We look forward to welcoming you.</span></p>
            </div>
            <div class="portal-property-gallery">
                <?php foreach ($propertyPhotos as $photoIndex => $photoPath) { ?>
                <figure class="portal-property-photo" data-reveal>
                    <img src="<?php echo e($photoPath); ?>" alt="Bongabong View Hotel — property photograph <?php echo $photoIndex + 1; ?>" loading="lazy" decoding="async">
                    <figcaption><span>Bongabong View</span><span><?php echo str_pad((string) ($photoIndex + 1), 2, '0', STR_PAD_LEFT); ?></span></figcaption>
                </figure>
                <?php } ?>
            </div>
        </div>
    </section>
    <?php } ?>

    <section class="portal-contact" id="plan-your-stay" aria-labelledby="contact-title">
        <div class="portal-container portal-contact-inner">
        <div class="portal-contact-intro" data-reveal>
            <p class="portal-eyebrow">Let’s plan your visit</p>
            <h2 id="contact-title">Your stay,<br><em>just a conversation away.</em></h2>
        </div>
        <div class="portal-contact-details" data-reveal>
            <p>Our front desk can help with room availability, current rates, and your reservation.</p>
            <a class="portal-contact-phone" href="tel:09228125061">0922 812 5061 <span aria-hidden="true"><?php echo ui_icon('arrow-up'); ?></span></a>
            <p class="portal-contact-address">JP Rizal St., Bgy. Poblacion<br>Bongabong, Oriental Mindoro</p>
        </div>
        </div>
    </section>
</main>

<?php render_footer(); ?>
</body>
</html>
