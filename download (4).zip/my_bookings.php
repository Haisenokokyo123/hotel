<?php
require_once __DIR__ . '/config.php';
require_once __DIR__ . '/gcash.php';
require_role('customer');
$conn = db_connect();
$customerId = (int) $_SESSION['user_id'];
$page = filter_var($_GET['page'] ?? 1, FILTER_VALIDATE_INT, ['options' => ['min_range' => 1, 'max_range' => 10000]]) ?: 1;
$offset = ($page - 1) * 50;
$attempts = [];
$stats = ['upcoming' => 0, 'paid' => 0, 'pending' => 0];
$nextStay = null;
if (payment_attempts_available($conn)) {
    $statement = $conn->prepare("SELECT p.*, rooms.room_name, r.id AS booking_id, r.check_in, r.check_out, r.is_archived,
        r.full_name AS booked_name, r.hours AS booked_nights, r.total_amount AS booked_amount,
        s.state AS reservation_state, s.scheduled_check_in, s.scheduled_check_out
        FROM payment_attempts p LEFT JOIN rooms ON rooms.id = p.room_id
        LEFT JOIN reservations r ON r.id = p.reservation_id
        LEFT JOIN reservation_states s ON s.reservation_id = r.id
        WHERE p.customer_id = ? ORDER BY p.id DESC LIMIT 51 OFFSET ?");
    $statement->bind_param('ii', $customerId, $offset);
    $statement->execute();
    $attempts = $statement->get_result()->fetch_all(MYSQLI_ASSOC);
    $statement = $conn->prepare("SELECT
        COALESCE(SUM(p.status = 'paid'), 0) AS paid,
        COALESCE(SUM(p.status = 'pending' AND p.expires_at > NOW()), 0) AS pending,
        COALESCE(SUM(p.status = 'paid' AND r.id IS NOT NULL AND COALESCE(s.state, 'reserved') = 'reserved' AND r.check_out > NOW()), 0) AS upcoming
        FROM payment_attempts p LEFT JOIN reservations r ON r.id = p.reservation_id
        LEFT JOIN reservation_states s ON s.reservation_id = r.id WHERE p.customer_id = ?");
    $statement->bind_param('i', $customerId);
    $statement->execute();
    $stats = $statement->get_result()->fetch_assoc();
    $statement = $conn->prepare("SELECT r.id, r.full_name, r.total_amount, rooms.room_name,
        s.state AS reservation_state, COALESCE(s.scheduled_check_in, r.check_in) AS arrival,
        COALESCE(s.scheduled_check_out, r.check_out) AS departure
        FROM reservations r JOIN rooms ON rooms.id = r.room_id
        LEFT JOIN reservation_states s ON s.reservation_id = r.id
        WHERE r.is_archived = 0 AND COALESCE(s.state, 'reserved') IN ('reserved', 'checked_in')
        AND r.check_out > NOW() AND EXISTS (SELECT 1 FROM payment_attempts p WHERE p.reservation_id = r.id AND p.customer_id = ? AND p.status = 'paid')
        ORDER BY (s.state = 'checked_in') DESC, arrival ASC, r.id ASC LIMIT 1");
    $statement->bind_param('i', $customerId);
    $statement->execute();
    $nextStay = $statement->get_result()->fetch_assoc();
}
$hasNext = count($attempts) > 50;
if ($hasNext) array_pop($attempts);
?>
<!doctype html><html lang="en"><head>
    <meta charset="utf-8"><meta name="viewport" content="width=device-width, initial-scale=1">
    <title>My bookings — Bongabong View Hotel</title>
    <link rel="stylesheet" href="style.css?v=<?php echo filemtime(__DIR__ . '/style.css'); ?>">
    <link rel="stylesheet" href="bookings.css?v=<?php echo filemtime(__DIR__ . '/bookings.css'); ?>">
    <link rel="stylesheet" href="portals.css?v=<?php echo filemtime(__DIR__ . '/portals.css'); ?>">
</head><body class="portal-body portal-guest-page portal-bookings-page">
<?php render_navbar(); ?>
<main class="portal-page portal-container portal-bookings-content" id="main-content">
    <div class="portal-section-heading"><div><p class="portal-eyebrow">Your reservations and payments</p><h1>My bookings</h1><p class="portal-bookings-intro">Your stays, payment updates, and digital receipts in one place.</p></div><a class="portal-button" href="customer_home.php#our-rooms">Reserve a room <?php echo ui_icon('arrow'); ?></a></div>
    <?php if ($nextStay) { ?>
    <section class="portal-next-stay" aria-labelledby="next-stay-title">
        <div><p class="portal-eyebrow"><?php echo $nextStay['reservation_state'] === 'checked_in' ? 'Your current stay' : 'Your next stay'; ?></p><h2 id="next-stay-title"><?php echo e($nextStay['room_name']); ?></h2><p>Reservation #<?php echo (int) $nextStay['id']; ?> · <?php echo e($nextStay['full_name']); ?></p></div>
        <dl><div><dt>Arrival</dt><dd><?php echo e(date('M j, Y · g:i A', strtotime($nextStay['arrival']))); ?></dd></div><div><dt>Departure</dt><dd><?php echo e(date('M j, Y · g:i A', strtotime($nextStay['departure']))); ?></dd></div></dl>
        <a class="portal-button" href="receipt.php?id=<?php echo (int) $nextStay['id']; ?>">View digital receipt <?php echo ui_icon('arrow-up'); ?></a>
    </section>
    <?php } ?>
    <section class="dashboard simple-dashboard my-bookings-stats" aria-label="Your booking overview">
        <div class="dash-card"><p>Upcoming reservations</p><h2><?php echo (int) $stats['upcoming']; ?></h2></div>
        <div class="dash-card"><p>Confirmed payments</p><h2><?php echo (int) $stats['paid']; ?></h2></div>
        <div class="dash-card"><p>Payments awaiting confirmation</p><h2><?php echo (int) $stats['pending']; ?></h2></div>
    </section>
    <div class="booking-list">
    <?php foreach ($attempts as $attempt) {
        $paymentStatus = $attempt['status'];
        if ($paymentStatus === 'pending' && strtotime($attempt['expires_at']) <= time()) $paymentStatus = 'expired';
        $paymentLabels = ['paid' => 'Paid', 'pending' => 'Awaiting confirmation', 'failed' => 'Not confirmed', 'expired' => 'Confirmation window ended', 'cancelled' => 'Checkout cancelled'];
        $label = $paymentLabels[$paymentStatus] ?? 'Needs review';
        $state = $attempt['booking_id'] ? reservation_state($attempt) : null;
        $storedBooking = json_decode($attempt['provider_payload'] ?? '', true);
        try { $stay = $attempt['booking_id'] ? ['check_in' => $attempt['scheduled_check_in'] ?? $attempt['check_in'], 'check_out' => $attempt['scheduled_check_out'] ?? $attempt['check_out']] : (isset($storedBooking['booking']) ? payment_attempt_stay($attempt) : null); }
        catch (Throwable $error) { $stay = null; }
    ?>
        <article class="panel-box booking-card" id="booking-<?php echo (int) $attempt['id']; ?>">
            <div class="booking-card-heading">
                <div><p class="portal-eyebrow"><?php echo $attempt['booking_id'] ? 'Reservation #' . (int) $attempt['booking_id'] : 'Payment attempt #' . (int) $attempt['id']; ?></p><h2><?php echo e($attempt['room_name'] ?? 'Hotel reservation'); ?></h2><p><?php echo e($attempt['booked_name'] ?? $attempt['full_name']); ?></p></div>
                <dl class="portal-booking-statuses">
                    <div><dt>Payment status</dt><dd><span class="booking-badge booking-badge--<?php echo e(in_array($paymentStatus, ['paid', 'pending', 'failed', 'expired', 'cancelled'], true) ? $paymentStatus : 'failed'); ?>"><?php echo e($label); ?></span></dd></div>
                    <div><dt>Booking status</dt><dd><span class="booking-badge booking-badge--<?php echo e($state ?: 'pending'); ?>"><?php echo $state ? e(reservation_status($attempt)) : ($paymentStatus === 'paid' ? 'Needs hotel review' : 'Not confirmed'); ?></span></dd></div>
                </dl>
            </div>
            <dl class="booking-details"><div><dt>Arrival</dt><dd><?php echo $stay ? e(date('M j, Y · g:i A', strtotime($stay['check_in']))) : 'Contact the front desk'; ?></dd></div><div><dt>Departure</dt><dd><?php echo $stay ? e(date('M j, Y · g:i A', strtotime($stay['check_out']))) : 'Contact the front desk'; ?></dd></div><div><dt>Nights</dt><dd><?php echo (int) ($attempt['booked_nights'] ?? $attempt['nights']); ?></dd></div><div><dt>Booking amount</dt><dd><?php echo money($attempt['booked_amount'] ?? $attempt['amount']); ?></dd></div></dl>
            <?php if ($state === 'cancelled' || $state === 'no_show') { ?><p class="form-note">The payment remains on record. For any refund or changes, please contact the front desk.</p><?php } ?>
            <?php if ($paymentStatus !== 'paid') { ?><p class="form-note">This attempt has no confirmed booking yet. If your wallet was charged, check payment again or contact the hotel before paying again.</p><?php } ?>
            <?php if ($paymentStatus === 'paid' && !$attempt['booking_id']) { ?><p class="form-note">Your payment is recorded. Contact the hotel to confirm your reservation details.</p><?php } ?>
            <div class="booking-actions">
                <?php if ($paymentStatus === 'paid' && $attempt['booking_id']) { ?><a href="receipt.php?id=<?php echo (int) $attempt['booking_id']; ?>" class="portal-button">View digital receipt <?php echo ui_icon('arrow-up'); ?></a><?php } ?>
                <?php if ($paymentStatus !== 'paid' && $attempt['provider_checkout_id']) { ?><a href="gcash_return.php?token=<?php echo e(rawurlencode($attempt['booking_token'])); ?>" class="secondary-btn">Check payment status</a><?php } ?>
                <a class="receipt-link" href="tel:09228125061">Contact the hotel</a>
            </div>
        </article>
    <?php } ?>
    <?php if (!$attempts) { ?><div class="empty-card"><h2><?php echo $page > 1 ? 'No more bookings.' : 'Your next stay starts here.'; ?></h2><p><?php echo $page > 1 ? 'Return to the previous page to see your bookings.' : 'Reservations made through your guest account will appear here.'; ?></p><a class="receipt-link" href="customer_home.php#our-rooms">Explore rooms</a></div><?php } ?>
    </div>
    <nav class="booking-pagination" aria-label="Booking history pages"><?php if ($page > 1) { ?><a class="secondary-btn" href="my_bookings.php?page=<?php echo $page - 1; ?>">← Previous</a><?php } ?><span>Page <?php echo $page; ?></span><?php if ($hasNext) { ?><a class="secondary-btn" href="my_bookings.php?page=<?php echo $page + 1; ?>">Next →</a><?php } ?></nav>
</main><?php render_footer(); ?></body></html>
