<?php
require_once __DIR__ . '/config.php';
start_app_session();

if (isset($_SESSION['role'])) {
    header('Location: ' . role_home($_SESSION['role']));
    exit;
}

$error = '';
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    require_csrf();
    $user = null;
    try {
        $user = authenticate_user($_POST['email'] ?? '', $_POST['password'] ?? '');
    } catch (LoginRateLimitException $exception) {
        http_response_code(429);
        header('Retry-After: 900');
        $error = $exception->getMessage();
    } catch (Throwable $exception) {
        error_log('Sign-in failed: ' . $exception->getMessage());
        $error = 'Sign-in is temporarily unavailable. Please try again.';
    }
    if ($user !== null) {
        establish_user_session($user);
        header('Location: ' . role_home($user['role']));
        exit;
    }
    if ($error === '') $error = 'Incorrect email or password.';
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="theme-color" content="#183d34">
    <title>Sign in · Bongabong View Hotel</title>
    <link rel="stylesheet" href="style.css?v=<?php echo filemtime(__DIR__ . '/style.css'); ?>">
    <link rel="stylesheet" href="auth.css?v=<?php echo filemtime(__DIR__ . '/auth.css'); ?>">
    <script src="auth.js?v=20261008" defer></script>
</head>
<body class="auth-page">
    <a class="auth-skip" href="#sign-in-form">Skip to sign in</a>
    <main class="auth-shell">
        <section class="auth-visual" aria-label="Bongabong View Hotel">
            <img class="auth-property-photo" src="hoteru.png" alt="The facade of Bongabong View Hotel" fetchpriority="high">
            <div class="auth-visual-shade"></div>
            <a class="auth-brand" href="login.php" aria-label="Bongabong View Hotel home">
                <span class="auth-monogram" aria-hidden="true">BV</span>
                <span class="auth-wordmark">Bongabong View<small>HOTEL &amp; RESTAURANT</small></span>
            </a>
            <div class="auth-visual-copy">
                <span class="auth-kicker">BONGABONG · ORIENTAL MINDORO</span>
                <h2>Every stay begins<br>with a warm welcome.</h2>
                <p>Your place in Bongabong, Oriental Mindoro.</p>
            </div>
            <div class="auth-visual-footer">
                <span>A little closer to feeling at home.</span>
                <span class="auth-location-mark" aria-hidden="true">BV / PH</span>
            </div>
        </section>
        <section class="auth-content" aria-labelledby="auth-heading">
            <div class="auth-content-top"><span>A familiar welcome</span></div>
            <div class="auth-form-wrap">
                <p class="auth-eyebrow">Welcome to Bongabong View</p>
                <h1 id="auth-heading">Welcome back<span class="auth-heading-dot">.</span></h1>
                <p class="auth-description">Sign in to manage your stay or step into your hotel workspace.</p>
                <?php if ($error !== '') { ?>
                    <div class="auth-message auth-message--error" role="alert"><?php echo e($error); ?></div>
                <?php } ?>

                <form class="auth-form" id="sign-in-form" method="POST">
                    <input type="hidden" name="csrf_token" value="<?php echo e(csrf_token()); ?>">

                    <div class="auth-field">
                        <label for="email">Email address</label>
                        <input id="email" type="email" name="email" autocomplete="username" maxlength="100" placeholder="you@example.com" value="<?php echo e(is_string($_POST['email'] ?? null) ? $_POST['email'] : ''); ?>" required>
                    </div>
                    <div class="auth-field">
                        <label for="password">Password</label>
                        <div class="auth-password-wrap">
                            <input id="password" type="password" name="password" autocomplete="current-password" placeholder="Enter your password" required>
                            <button class="auth-password-toggle" type="button" aria-label="Show password" aria-controls="password" aria-pressed="false">Show</button>
                        </div>
                    </div>
                    <button class="auth-submit" type="submit" name="login"><span>Sign in</span><svg viewBox="0 0 24 24" fill="none" aria-hidden="true"><path d="M5 12h14m-5-5 5 5-5 5" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"/></svg></button>
                </form>
                <div class="auth-divider"></div>
                <p class="auth-create-account">New to Bongabong View?<br><a href="customer_register.php">Create a guest account <?php echo ui_icon('arrow'); ?></a></p>
            </div>
            <footer class="auth-content-footer"><span>Bongabong View Hotel</span><span>Stay a little closer.</span></footer>
        </section>
    </main>
</body>
</html>
