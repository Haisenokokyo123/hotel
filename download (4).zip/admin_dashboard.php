<?php
require_once __DIR__ . '/config.php';
require_role('admin');
header('Cache-Control: private, no-store');

$views = ['overview' => 'Overview', 'staff' => 'Staff accounts', 'customers' => 'Customer directory'];
$view = is_string($_GET['view'] ?? null) && isset($views[$_GET['view']]) ? $_GET['view'] : 'overview';
$error = '';
$success = $_SESSION['admin_success'] ?? '';
unset($_SESSION['admin_success']);
$oldName = $oldEmail = '';
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    require_csrf();
    $view = 'staff';
    $oldName = is_string($_POST['name'] ?? null) ? trim($_POST['name']) : '';
    $oldEmail = is_string($_POST['email'] ?? null) ? trim($_POST['email']) : '';
    try {
        if (($_POST['action'] ?? '') !== 'create_staff') throw new InvalidArgumentException('Choose a valid staff account action.');
        $password = $_POST['password'] ?? null;
        $confirmation = $_POST['password_confirmation'] ?? null;
        if (!is_string($password) || !is_string($confirmation) || $password !== $confirmation) {
            throw new InvalidArgumentException('The passwords must match.');
        }
        register_staff($oldName, $oldEmail, $password);
        $_SESSION['admin_success'] = 'Staff account created for ' . $oldName . '. They can now sign in using their email address.';
        header('Location: admin_dashboard.php?view=staff', true, 303);
        exit;
    } catch (InvalidArgumentException $exception) {
        http_response_code(422);
        $error = $exception->getMessage();
    } catch (Throwable $exception) {
        error_log('Admin staff creation failed: ' . $exception->getMessage());
        http_response_code(503);
        $error = 'The staff account could not be created. Please try again.';
    }
}

$conn = db_connect();
$search = is_string($_GET['search'] ?? null) ? mb_substr(trim($_GET['search']), 0, 100) : '';
$page = filter_var($_GET['page'] ?? 1, FILTER_VALIDATE_INT, ['options' => ['min_range' => 1]]) ?: 1;
$accountCounts = ['staff' => 0, 'customer' => 0];
foreach ($conn->query("SELECT role, COUNT(*) AS total FROM users WHERE role IN ('staff', 'customer') GROUP BY role") as $row) {
    $accountCounts[$row['role']] = (int) $row['total'];
}
if ($view === 'overview') {
    $rooms = $conn->query('SELECT COUNT(*) AS total, COALESCE(SUM(is_active = 1), 0) AS active FROM rooms')->fetch_assoc();
    $stays = $conn->query("SELECT COUNT(*) AS total, COALESCE(SUM(state = 'reserved'), 0) AS reserved, COALESCE(SUM(state = 'checked_in'), 0) AS checked_in FROM reservation_states")->fetch_assoc();
    $monthly = $conn->query("SELECT COUNT(*) AS bookings, COALESCE(SUM(total_amount), 0) AS amount FROM reservations WHERE date_created >= DATE_FORMAT(CURDATE(), '%Y-%m-01') AND date_created < DATE_ADD(DATE_FORMAT(CURDATE(), '%Y-%m-01'), INTERVAL 1 MONTH)")->fetch_assoc();
    $recent = $conn->query("SELECT r.id, r.full_name, r.contact_number, r.check_in, r.check_out, r.total_amount, rooms.room_name, s.state FROM reservations r LEFT JOIN rooms ON rooms.id = r.room_id LEFT JOIN reservation_states s ON s.reservation_id = r.id ORDER BY r.id DESC LIMIT 8")->fetch_all(MYSQLI_ASSOC);
} else {
    $role = $view === 'staff' ? 'staff' : 'customer';
    $pattern = '%' . $search . '%';
    $statement = $conn->prepare('SELECT COUNT(*) AS total FROM users WHERE role = ? AND (name LIKE ? OR email LIKE ?)');
    $statement->bind_param('sss', $role, $pattern, $pattern);
    $statement->execute();
    $total = (int) $statement->get_result()->fetch_assoc()['total'];
    $pages = max(1, (int) ceil($total / 20));
    $page = min($page, $pages);
    $offset = ($page - 1) * 20;
    $statement = $conn->prepare('SELECT id, name, email FROM users WHERE role = ? AND (name LIKE ? OR email LIKE ?) ORDER BY name, id LIMIT 20 OFFSET ?');
    $statement->bind_param('sssi', $role, $pattern, $pattern, $offset);
    $statement->execute();
    $people = $statement->get_result()->fetch_all(MYSQLI_ASSOC);
}
$conn->close();
$stateLabels = ['reserved' => 'Reserved', 'checked_in' => 'Checked in', 'checked_out' => 'Checked out', 'cancelled' => 'Cancelled', 'no_show' => 'No-show'];
?>
<!doctype html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title><?php echo e($views[$view]); ?> · Administration · Bongabong View Hotel</title>
    <link rel="stylesheet" href="style.css?v=<?php echo filemtime(__DIR__ . '/style.css'); ?>">
    <link rel="stylesheet" href="admin.css?v=<?php echo filemtime(__DIR__ . '/admin.css'); ?>">
</head>
<body class="admin-page">
<?php render_navbar(''); ?>
<main class="page-wrapper admin-main" id="main-content">
    <header class="admin-heading">
        <div><span class="eyebrow">Hotel administration</span><h1>Welcome, <?php echo e($_SESSION['name']); ?>.</h1><p>Manage your team and keep an eye on the hotel.</p></div>
        <a class="secondary-btn" href="index.php">Open front desk <?php echo ui_icon('arrow-up'); ?></a>
    </header>
    <nav class="admin-tabs" aria-label="Administration">
        <?php foreach ($views as $key => $label) { ?><a href="admin_dashboard.php?view=<?php echo e($key); ?>"<?php echo $view === $key ? ' class="is-active" aria-current="page"' : ''; ?>><?php echo e($label); ?><?php if ($key !== 'overview') { ?><span><?php echo $accountCounts[$key === 'staff' ? 'staff' : 'customer']; ?></span><?php } ?></a><?php } ?>
    </nav>
    <?php if ($success !== '') { ?><div class="success-box page-alert" role="status"><?php echo e($success); ?></div><?php } ?>
    <?php if ($error !== '') { ?><div class="error-box page-alert" role="alert"><?php echo e($error); ?></div><?php } ?>

    <?php if ($view === 'overview') { ?>
    <section class="admin-summary" aria-label="Hotel overview">
        <a class="admin-stat" href="rooms.php"><span>Active rooms</span><strong><?php echo (int) $rooms['active']; ?></strong><small><?php echo (int) $rooms['total']; ?> rooms in the hotel <?php echo ui_icon('arrow-up'); ?></small></a>
        <a class="admin-stat" href="calendar.php"><span>Current stays</span><strong><?php echo (int) $stays['checked_in']; ?></strong><small><?php echo (int) $stays['reserved']; ?> reservations awaiting check-in <?php echo ui_icon('arrow-up'); ?></small></a>
        <a class="admin-stat" href="admin_dashboard.php?view=staff"><span>Staff accounts</span><strong><?php echo $accountCounts['staff']; ?></strong><small>Manage your hotel team <?php echo ui_icon('arrow-up'); ?></small></a>
        <a class="admin-stat" href="admin_dashboard.php?view=customers"><span>Customer accounts</span><strong><?php echo $accountCounts['customer']; ?></strong><small>View names and email addresses <?php echo ui_icon('arrow-up'); ?></small></a>
    </section>
    <section class="admin-tools" aria-label="Hotel management tools">
        <div class="admin-month"><span class="eyebrow"><?php echo e(date('F Y')); ?></span><h2><?php echo money($monthly['amount']); ?></h2><p>Recorded booking value · <?php echo (int) $monthly['bookings']; ?> bookings</p><small>Includes recorded bookings that were later cancelled or marked no-show.</small><a href="reports.php">View sales reports <?php echo ui_icon('arrow-up'); ?></a></div>
        <a class="admin-tool" href="rooms.php"><?php echo ui_icon('bed'); ?><h3>Rooms &amp; rates</h3><p>Manage rooms, prices, photographs, and guest amenities.</p><span>Manage rooms ↗</span></a>
        <a class="admin-tool" href="calendar.php"><?php echo ui_icon('clock'); ?><h3>Reservations</h3><p>Review stays and manage check-in, check-out, and cancellations.</p><span>Open calendar ↗</span></a>
        <a class="admin-tool" href="transactions.php"><?php echo ui_icon('chart'); ?><h3>Guest records</h3><p>View guest contact details, booking amounts, payments, and receipts.</p><span>View transactions ↗</span></a>
    </section>
    <section class="admin-panel" aria-labelledby="recent-title">
        <div class="admin-panel-heading"><div><h2 id="recent-title">Recent bookings</h2><p>The latest reservations recorded by the hotel.</p></div><a href="transactions.php">View all ↗</a></div>
        <div class="admin-table-scroll"><table class="admin-table"><thead><tr><th scope="col">Guest</th><th scope="col">Room</th><th scope="col">Stay dates</th><th scope="col">Status</th><th scope="col">Booking value</th></tr></thead><tbody>
        <?php foreach ($recent as $booking) { ?><tr><td><a href="transactions.php?search=<?php echo e(rawurlencode($booking['full_name'] ?? '')); ?>"><strong><?php echo e($booking['full_name'] ?: 'Guest'); ?></strong><small><?php echo e($booking['contact_number']); ?></small></a></td><td><?php echo e($booking['room_name'] ?: 'Room unavailable'); ?></td><td><?php echo e(date('M j, Y', strtotime($booking['check_in']))); ?><small>to <?php echo e(date('M j, Y', strtotime($booking['check_out']))); ?></small></td><td><span class="admin-status"><?php echo e($stateLabels[$booking['state']] ?? 'Needs review'); ?></span></td><td><?php echo money($booking['total_amount']); ?></td></tr><?php } ?>
        <?php if (!$recent) { ?><tr><td colspan="5" class="admin-empty">No bookings yet. Reservations will appear here when recorded.</td></tr><?php } ?>
        </tbody></table></div>
    </section>
    <?php } else { ?>
    <div class="admin-account-layout<?php echo $view === 'customers' ? ' admin-account-layout--directory' : ''; ?>">
        <?php if ($view === 'staff') { ?>
        <section class="admin-panel admin-create" aria-labelledby="staff-title"><span class="eyebrow">Grow your team</span><h2 id="staff-title">Create a staff account</h2><p>Give a team member access to the front desk, rooms, reservations, and reports.</p>
            <form method="POST" action="admin_dashboard.php?view=staff">
                <input type="hidden" name="csrf_token" value="<?php echo e(csrf_token()); ?>">
                <input type="hidden" name="action" value="create_staff">
                <label for="staff-name">Full name</label><input id="staff-name" name="name" maxlength="100" autocomplete="off" value="<?php echo e($oldName); ?>" required>
                <label for="staff-email">Email address</label><input id="staff-email" name="email" type="email" maxlength="100" autocomplete="off" value="<?php echo e($oldEmail); ?>" required>
                <label for="staff-password">Password</label><input id="staff-password" name="password" type="password" minlength="8" maxlength="72" autocomplete="new-password" aria-describedby="password-help" required><small id="password-help">Use at least 8 characters. Share the login details privately with this staff member.</small>
                <label for="staff-password-confirmation">Confirm password</label><input id="staff-password-confirmation" name="password_confirmation" type="password" minlength="8" maxlength="72" autocomplete="new-password" required>
                <button class="primary-btn" type="submit">Create staff account <?php echo ui_icon('plus'); ?></button>
            </form>
        </section>
        <?php } ?>
        <section class="admin-panel" aria-labelledby="directory-title">
            <div class="admin-panel-heading"><div><h2 id="directory-title"><?php echo $view === 'staff' ? 'Your hotel team' : 'Customer directory'; ?></h2><p><?php echo $total; ?> <?php echo $view === 'staff' ? 'staff accounts' : 'customer accounts'; ?><?php echo $search !== '' ? ' matching your search' : ''; ?></p></div></div>
            <form class="admin-search" action="admin_dashboard.php" method="GET"><input type="hidden" name="view" value="<?php echo e($view); ?>"><label for="directory-search">Search by name or email</label><div><input id="directory-search" name="search" type="search" maxlength="100" value="<?php echo e($search); ?>" placeholder="Name or email address"><button type="submit" class="secondary-btn">Search</button></div><?php if ($search !== '') { ?><a href="admin_dashboard.php?view=<?php echo e($view); ?>">Clear search</a><?php } ?></form>
            <div class="admin-table-scroll"><table class="admin-table"><thead><tr><th scope="col">Name</th><th scope="col">Email address</th><th scope="col">Access</th></tr></thead><tbody>
            <?php foreach ($people as $person) { ?><tr><td><strong><?php echo e($person['name']); ?></strong><small>Account #<?php echo (int) $person['id']; ?></small></td><td><?php echo e($person['email']); ?></td><td><span class="admin-status"><?php echo $view === 'staff' ? 'Front desk' : 'Guest portal'; ?></span></td></tr><?php } ?>
            <?php if (!$people) { ?><tr><td colspan="3" class="admin-empty"><?php echo $search !== '' ? 'No accounts match this search.' : ($view === 'staff' ? 'Create your first staff account using the form.' : 'Customer accounts will appear after registration.'); ?></td></tr><?php } ?>
            </tbody></table></div>
            <nav class="admin-pagination" aria-label="Directory pages"><span>Page <?php echo $page; ?> of <?php echo $pages; ?></span><div><?php foreach (['Previous' => $page - 1, 'Next' => $page + 1] as $label => $target) { if ($target < 1 || $target > $pages) continue; ?><a href="admin_dashboard.php?<?php echo e(http_build_query(['view' => $view, 'search' => $search, 'page' => $target])); ?>"><?php echo e($label); ?> <?php echo $label === 'Next' ? '→' : ''; ?></a><?php } ?></div></nav>
        </section>
    </div>
    <?php } ?>
</main>
<?php render_footer(''); ?>
</body>
</html>
