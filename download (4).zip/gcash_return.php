<?php
require_once __DIR__ . '/config.php';
require_once __DIR__ . '/gcash.php';
require_role('customer');
$token = is_string($_GET['token'] ?? null) ? $_GET['token'] : '';
if (!preg_match('/\A[a-f0-9]{64}\z/', $token)) {
    header('Location: customer_home.php');
    exit;
}
$cancelled = isset($_GET['cancelled']);
// Returning from checkout is not proof of either payment or cancellation.
?>
<!doctype html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Confirming online payment — Bongabong View Hotel</title>
    <link rel="stylesheet" href="style.css?v=<?php echo filemtime(__DIR__ . '/style.css'); ?>">
    <link rel="stylesheet" href="portals.css?v=<?php echo filemtime(__DIR__ . '/portals.css'); ?>">
    <script src="payment-return.js?v=<?php echo filemtime(__DIR__ . '/payment-return.js'); ?>" defer></script>
</head>
<body class="portal-body portal-guest-page">
<?php render_navbar(); ?>
<main class="portal-page" id="main-content"><section id="payment-verification" class="portal-container portal-empty" aria-live="polite" data-token="<?php echo e($token); ?>" data-csrf="<?php echo e(csrf_token()); ?>">
    <p class="portal-eyebrow">Secure online payment</p>
    <h1 id="payment-title">Confirming your payment…</h1>
    <p id="payment-message"><?php echo $cancelled ? 'You returned from checkout. We are checking whether a payment was completed before you left.' : 'We are checking your payment with PayMongo and confirming your room.'; ?></p>
    <a class="portal-button" id="payment-action" href="customer_home.php#our-rooms">Return to rooms</a>
    <p>If your wallet was charged, please do not pay again while confirmation is pending.</p>
    <p>Need help? <a href="tel:09228125061">Call the front desk: 0922 812 5061</a></p>
    <noscript><p>Enable JavaScript to check your payment, or contact the front desk with your payment reference.</p></noscript>
</section></main>
<?php render_footer(); ?>
</body>
</html>
