<?php
require_once __DIR__ . '/config.php';
require_staff();
require_csrf();
$id = filter_var($_POST['reservation_id'] ?? null, FILTER_VALIDATE_INT, ['options' => ['min_range' => 1]]);
$action = is_string($_POST['action'] ?? null) ? $_POST['action'] : '';
$date = is_string($_POST['date'] ?? null) && preg_match('/\A\d{4}-\d{2}-\d{2}\z/', $_POST['date']) ? $_POST['date'] : date('Y-m-d');
$days = filter_var($_POST['days'] ?? 14, FILTER_VALIDATE_INT);
if (!in_array($days, [7, 14, 30], true)) $days = 14;
try {
    if (!$id) throw new InvalidArgumentException('Choose a valid reservation.');
    $conn = db_connect();
    change_reservation_state($conn, $id, $action, (int) $_SESSION['user_id']);
    $_SESSION['reservation_success'] = ['check_in' => 'Guest checked in.', 'check_out' => 'Guest checked out.', 'cancel' => 'Reservation cancelled. Payment records were kept.', 'no_show' => 'Guest marked as a no-show. Payment records were kept.'][$action];
} catch (InvalidArgumentException $error) {
    $_SESSION['reservation_error'] = $error->getMessage();
} catch (Throwable $error) {
    error_log('Reservation action failed: ' . $error->getMessage());
    $_SESSION['reservation_error'] = 'The reservation could not be updated. Please try again.';
}
header('Location: calendar.php?date=' . rawurlencode($date) . '&days=' . $days . '#reservation-' . (int) $id, true, 303);
exit;
