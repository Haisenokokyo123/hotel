<?php
require_once __DIR__ . '/config.php';
require_once __DIR__ . '/gcash.php';
start_app_session();

header('Content-Type: application/json; charset=utf-8');
header('Cache-Control: no-store');
if (($_SESSION['role'] ?? '') !== 'customer') {
    http_response_code(401);
    exit(json_encode(['status' => 'authentication_required']));
}
if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    http_response_code(405);
    header('Allow: POST');
    exit(json_encode(['status' => 'invalid']));
}
$csrf = $_POST['csrf_token'] ?? null;
if (!is_string($csrf) || !isset($_SESSION['csrf_token']) || !hash_equals($_SESSION['csrf_token'], $csrf)) {
    http_response_code(403);
    exit(json_encode(['status' => 'session_expired']));
}
$token = is_string($_POST['token'] ?? null) ? $_POST['token'] : '';
if (!preg_match('/\A[a-f0-9]{64}\z/', $token)) {
    http_response_code(400);
    echo json_encode(['status' => 'invalid']);
    exit;
}
$customerId = (int) ($_SESSION['user_id'] ?? $_SESSION['id'] ?? 0);
try {
    $conn = db_connect();
    if (!payment_attempts_available($conn)) throw new RuntimeException('Payment database migration is missing.');
    $statement = $conn->prepare('SELECT * FROM payment_attempts WHERE booking_token = ? AND customer_id = ? LIMIT 1');
    $statement->bind_param('si', $token, $customerId);
    $statement->execute();
    $attempt = $statement->get_result()->fetch_assoc();
    if (!$attempt) {
        http_response_code(404);
        exit(json_encode(['status' => 'missing']));
    }
    if ($attempt['status'] === 'paid' && $attempt['reservation_id']) {
        exit(json_encode(['status' => 'paid', 'receipt_url' => 'receipt.php?id=' . (int) $attempt['reservation_id']]));
    }
    // Repeated polls from this session share a short cooldown, including failures.
    $lastCheck = $_SESSION['payment_verification'] ?? [];
    if (($lastCheck['token'] ?? '') === $token && time() - ($lastCheck['at'] ?? 0) < 5) {
        exit(json_encode($lastCheck['result']));
    }
    $result = ['status' => 'pending'];
    try {
        $checkout = retrieve_payment_checkout($attempt['provider_checkout_id']);
        if (checkout_paid_payment($checkout, $attempt) !== null) {
            $reservationId = confirm_paid_online_payment_attempt($conn, $attempt['provider_checkout_id'], $checkout);
            $result = ['status' => 'paid', 'receipt_url' => 'receipt.php?id=' . $reservationId];
        } elseif (($checkout['attributes']['status'] ?? '') === 'expired' || strtotime($attempt['expires_at']) <= time()) {
            $result = ['status' => 'expired'];
        }
    } catch (PaymentBookingConflict | UnexpectedValueException $error) {
        error_log('Payment needs review for attempt ' . (int) $attempt['id'] . ': ' . $error->getMessage());
        $result = ['status' => 'review_required'];
    } catch (Throwable $error) {
        error_log('Payment verification failed for attempt ' . (int) $attempt['id'] . ': ' . $error->getMessage());
        $result = ['status' => 'verification_unavailable'];
    }
    // A webhook may have committed while the provider request was in flight.
    if ($result['status'] !== 'paid') {
        $statement->execute();
        $latest = $statement->get_result()->fetch_assoc();
        if ($latest && $latest['status'] === 'paid' && $latest['reservation_id']) {
            $result = ['status' => 'paid', 'receipt_url' => 'receipt.php?id=' . (int) $latest['reservation_id']];
        }
    }
    $_SESSION['payment_verification'] = ['token' => $token, 'at' => time(), 'result' => $result];
    echo json_encode($result);
} catch (Throwable $error) {
    error_log('Payment status unavailable: ' . $error->getMessage());
    http_response_code(503);
    echo json_encode(['status' => 'verification_unavailable']);
}
