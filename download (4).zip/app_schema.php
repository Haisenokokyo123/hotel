<?php

function ensure_app_schema($conn) {
    // Additive tables keep the existing rooms, users and reservation schema intact.
    $conn->query("CREATE TABLE IF NOT EXISTS room_guest_details (
        room_id INT PRIMARY KEY,
        guest_capacity INT NULL,
        bed_setup VARCHAR(100) NOT NULL DEFAULT '',
        amenities VARCHAR(500) NOT NULL DEFAULT ''
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4");
    $conn->query("CREATE TABLE IF NOT EXISTS auth_rate_limits (
        bucket CHAR(64) PRIMARY KEY,
        attempts INT NOT NULL DEFAULT 0,
        window_started DATETIME NOT NULL,
        blocked_until DATETIME NULL
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4");
    $conn->query("CREATE TABLE IF NOT EXISTS reservation_states (
        reservation_id INT PRIMARY KEY,
        state VARCHAR(20) NOT NULL,
        scheduled_check_in DATETIME NOT NULL,
        scheduled_check_out DATETIME NOT NULL,
        actual_check_in DATETIME NULL,
        actual_check_out DATETIME NULL,
        updated_by INT NULL,
        updated_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4");
    $conn->query("CREATE TABLE IF NOT EXISTS app_schema_migrations (
        version INT PRIMARY KEY,
        applied_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4");
    if (!$conn->query('SELECT version FROM app_schema_migrations WHERE version = 1')->fetch_assoc()) {
        // Preserve the old system's current occupancy when explicit states are introduced.
        $conn->query("INSERT IGNORE INTO reservation_states
            (reservation_id, state, scheduled_check_in, scheduled_check_out, actual_check_in, actual_check_out)
            SELECT id,
                CASE WHEN is_archived = 1 OR check_out <= NOW() THEN 'checked_out'
                     WHEN check_in <= NOW() THEN 'checked_in' ELSE 'reserved' END,
                check_in, check_out,
                CASE WHEN check_in <= NOW() THEN check_in ELSE NULL END,
                CASE WHEN is_archived = 1 OR check_out <= NOW() THEN check_out ELSE NULL END
            FROM reservations");
        $conn->query('INSERT IGNORE INTO app_schema_migrations (version) VALUES (1)');
    }
}
