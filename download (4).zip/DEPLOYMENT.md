# Account security and booking management

Upload the updated project files together. The new pages and supporting files are `calendar.php`, `reservation_action.php`, `my_bookings.php`, `bookings.css`, `accounts.php`, `reservations.php`, and `app_schema.php`.

On the first database connection, the application creates supporting tables: `auth_rate_limits`, `reservation_states`, `app_schema_migrations`, and `room_guest_details`. The database account needs permission to create tables. Existing reservation dates and current occupancy are copied into the new state table once. New customer bookings stay Reserved until staff uses Check in; checked-in guests remain occupied until Check out.

Registration uses hashed passwords, prepared statements, input validation, and CSRF tokens. Existing plaintext passwords up to 72 bytes are upgraded on successful sign-in. Failed logins are limited to five per account or twenty per IP within fifteen minutes, followed by a fifteen-minute cooldown. Passwords are never included in logs or login results.

Calendar staff actions preserve the original scheduled dates. Cancel and No-show release the reserved room and keep its payment record; they do not issue a refund. The customer My bookings page lists payments and reservations linked to that customer's account, with receipt and payment-status links.

Reports now separate front desk Cash, front desk GCash, and Online / QRPh booking values. Paid cancellations and no-shows remain included because no refund has been recorded.

## Validation

The regression scripts use a disposable local MySQL server on port 13317 with dummy credentials and payment keys; never run them against the hotel's production database. Run `tests/system_regression.php` for account security and reservation state transitions, `tests/payment_regression.php` in live and test modes for payment confirmation, and `tests/payment_return_regression.cjs` for verification-page behavior. `tests/http_regression.cjs` checks the local fixture server on port 18081 for CSRF rejection and authentication guards.

Local validation does not deploy the changes or verify the hosted database and live PayMongo account.

## Administration

Upload `admin_dashboard.php`, `admin.css`, `accounts.php`, and `config.php` directly into the hosting `htdocs` directory, beside `login.php` and `style.css`. Sign in with an existing account whose role is `admin`; login and the Administration navigation link open `admin_dashboard.php` directly. The main dashboard no longer depends on an `admin` folder. Uploading the optional `admin` folder also preserves older `/admin/dashboard.php` bookmarks by redirecting them to the root dashboard. No default administrator or password is created.

The admin dashboard shows room and account counts, current stays, recent bookings, and this month's recorded booking value. Existing Rooms, Calendar, Transactions, and Reports pages remain accessible to administrators. The Staff accounts tab creates staff users with hashed passwords, a fixed staff role, duplicate-email protection, and CSRF checks. The Customer directory provides searchable, paginated names and email addresses. These admin views require the administrator role; staff and customers receive HTTP 403. Passwords and payment API secrets are never listed. No additional database migration is needed for these views.

For administration validation, initialize the dedicated disposable MySQL server on port 13317 with dummy credentials. `tests/admin_fixture.php` creates and prints a generated test database name; configure the local PHP fixture server on port 18081 to use that database, `DB_HOST=127.0.0.1`, `DB_USER=root`, `DB_PASSWORD=payment_local_test_only`, and `DB_PORT=13317`. Use `php -d session.save_path=<writable_test_session_directory> -S 127.0.0.1:18081 -t .` so fixture sessions remain in a writable test directory. Run `node tests/admin_regression.cjs`. Afterwards, stop the fixture server and run `php tests/admin_fixture.php cleanup <generated_database_name>`. The fixture credentials and accounts are exclusively for local tests and must not be deployed as live accounts.

## Guest portal booking UI

Upload guest_booking.php, guest_availability.php, guest-forms.js, and the updated PHP/CSS/JS files together. Room management includes optional maximum guests, bed setup, and amenities fields. Existing rooms remain bookable; unknown room details are not invented. Fill these fields with confirmed property information to show them on the guest cards.

The location map in `customer_home.php` contains its own iframe document and map setup, loads Leaflet 1.9.4 from its public CDN, and uses OpenStreetMap tiles with the hotel's existing coordinates and a location pin. Zoom is available only through the + and − buttons; scrolling does not zoom the map. It does not require `guest-map.js` or `assets/leaflet` to be uploaded. To apply the map fix, upload the updated `customer_home.php` and refresh the customer page. The Google Maps directions link remains available if the map provider is unreachable.

The guest confirmation page and hotel-information section also use `guest_content.php`. Upload it with the updated `receipt.php`, `customer_home.php`, `config.php`, `payment-return.js`, `style.css`, and `portals.css`. The receipt shows the verified online payment amount separately from later stay charges, and its heading reflects the current reservation state. Cancellation and refund questions direct guests to the hotel until exact terms are supplied. The guest footer links to the supplied Bongabong View Facebook page.
