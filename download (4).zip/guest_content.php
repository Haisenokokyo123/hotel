<?php

function guest_confirmation_copy($state) {
    $messages = [
        'reserved' => ['Booking confirmed.', 'Your room is reserved and your online payment is recorded. We look forward to welcoming you.', 'check'],
        'checked_in' => ['Enjoy your stay.', 'You are checked in. Your reservation details and online payment are available below.', 'check'],
        'checked_out' => ['Thank you for staying with us.', 'Your stay is complete. You can review your reservation and online payment below.', 'check'],
        'cancelled' => ['Booking cancelled.', 'This reservation has been cancelled. Your payment remains on record. Contact the hotel for changes or refund eligibility.', 'info'],
        'no_show' => ['Your booking needs attention.', 'This reservation is marked as a no-show. Contact the hotel to discuss your booking and any applicable terms.', 'info'],
    ];
    return $messages[$state] ?? ['Your booking details.', 'Contact the hotel if you need help with this reservation.', 'info'];
}

function render_guest_information() {
    $questions = [
        'What time are check-in and check-out?' => 'Check-in is from 2:00 PM, and check-out is by 12:00 noon. If you need to arrive or leave outside these times, contact the hotel before your visit.',
        'How do I pay for an online booking?' => 'Choose your dates and room, enter your contact details, and continue to the secure QRPh checkout. Scan the code with GCash or another compatible wallet.',
        'When is my reservation confirmed?' => 'Your reservation is confirmed after payment is verified. If your wallet was charged and confirmation is still pending, check the payment status in My bookings or contact the hotel before paying again.',
        'Can I change or cancel my booking?' => 'Contact the hotel for changes, cancellations, and refund eligibility. The hotel will confirm the applicable terms for your reservation.',
        'Where can I find my receipt?' => 'After payment confirmation, open My bookings and select View digital receipt. Your receipt stays available in your account and can be viewed on your phone.',
    ];
    ?>
    <section class="portal-container portal-guest-information" id="hotel-information" aria-labelledby="hotel-information-title">
        <div class="portal-information-intro">
            <p class="portal-eyebrow">Before you arrive</p>
            <h2 id="hotel-information-title">Good to know<br><em>for your stay.</em></h2>
            <p>A few helpful details about your reservation, payment, and arrival.</p>
            <dl class="portal-arrival-times"><div><dt>Check-in</dt><dd>From 2:00 PM</dd></div><div><dt>Check-out</dt><dd>By 12:00 noon</dd></div></dl>
            <a class="portal-text-link" href="tel:09228125061">Ask the hotel <?php echo ui_icon('arrow-up'); ?></a>
        </div>
        <div class="portal-faq-list">
            <?php foreach ($questions as $question => $answer) { ?>
            <details class="portal-faq-item">
                <summary><?php echo e($question); ?><span aria-hidden="true"><?php echo ui_icon('plus'); ?></span></summary>
                <p><?php echo e($answer); ?></p>
            </details>
            <?php } ?>
        </div>
    </section>
    <?php
}
