(() => {
  const container = document.getElementById('hotel-location-map');
  if (!container || !window.L) return;

  const location = [Number(container.dataset.latitude), Number(container.dataset.longitude)];
  if (!location.every(Number.isFinite)) return;

  const initialize = () => {
    container.replaceChildren();
    const map = L.map(container, {
      scrollWheelZoom: false,
      zoomControl: true,
      closePopupOnClick: false,
    }).setView(location, 16);

    L.tileLayer(container.dataset.tileUrl, {
      maxZoom: 19,
      attribution: '&copy; <a href="https://www.openstreetmap.org/copyright" target="_blank" rel="noopener noreferrer">OpenStreetMap</a> contributors',
    }).addTo(map);

    // Highlight the property and keep its label attached to the exact location.
    L.circle(location, {
      radius: 25,
      color: '#b28a45',
      weight: 2,
      fillColor: '#e5bf78',
      fillOpacity: 0.3,
      interactive: false,
    }).addTo(map);

    L.marker(location, {
      title: 'Bongabong View Hotel — We are here!',
      alt: 'Bongabong View Hotel location',
    }).addTo(map)
      .bindPopup('<strong>We are here!</strong><span>Bongabong View Hotel</span>', {
        className: 'portal-hotel-popup',
        closeOnClick: false,
        autoClose: false,
      })
      .openPopup();
  };

  // Load only the tiles needed when the guest reaches the map.
  if ('IntersectionObserver' in window) {
    const observer = new IntersectionObserver((entries) => {
      if (!entries.some((entry) => entry.isIntersecting)) return;
      observer.disconnect();
      initialize();
    });
    observer.observe(container);
  } else {
    initialize();
  }
})();
