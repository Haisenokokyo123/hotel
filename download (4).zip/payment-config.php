<?php

return [
    'PAYMONGO_SECRET_KEY' => 'sk_live_rjtw2S1xMudQttBg8xgocwvJ',
    'PAYMONGO_WEBHOOK_SECRET' => 'whsk_EzqaDNgBA7FzwKgvLVBAv4vQ',
    'APP_BASE_URL' => 'https://hoteruhotel.42web.io/',
];