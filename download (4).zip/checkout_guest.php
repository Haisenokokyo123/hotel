<?php
// Keep existing front desk checkout forms compatible with the stateful action.
$_POST['action'] = 'check_out';
require __DIR__ . '/reservation_action.php';
