<?php
require_once __DIR__ . '/config.php';
require_once __DIR__ . '/gcash.php';
require_staff();
$conn = db_connect();
$dateValue = is_string($_GET['date'] ?? null) ? $_GET['date'] : date('Y-m-d');
$start = DateTimeImmutable::createFromFormat('!Y-m-d', $dateValue);
if (!$start || $start->format('Y-m-d') !== $dateValue) $start = new DateTimeImmutable('today');
$days = filter_var($_GET['days'] ?? 14, FILTER_VALIDATE_INT);
if (!in_array($days, [7, 14, 30], true)) $days = 14;
$end = $start->modify('+' . $days . ' days');
$dateValue = $start->format('Y-m-d');
$startSql = $start->format('Y-m-d H:i:s');
$endSql = $end->format('Y-m-d H:i:s');
$rooms = $conn->query('SELECT * FROM rooms WHERE is_active = 1 ORDER BY room_name')->fetch_all(MYSQLI_ASSOC);
$statement = $conn->prepare("SELECT r.*, rooms.room_name, s.state AS reservation_state,
    s.scheduled_check_in, s.scheduled_check_out, s.actual_check_in, s.actual_check_out
    FROM reservations r LEFT JOIN rooms ON rooms.id = r.room_id
    LEFT JOIN reservation_states s ON s.reservation_id = r.id
    WHERE (COALESCE(s.scheduled_check_in, r.check_in) < ? AND COALESCE(s.scheduled_check_out, r.check_out) >= ?)
       OR (s.state = 'checked_in' AND r.check_in < ?)
    ORDER BY r.check_in, r.id");
$statement->bind_param('sss', $endSql, $startSql, $endSql);
$statement->execute();
$reservations = $statement->get_result()->fetch_all(MYSQLI_ASSOC);
$byRoom = [];
foreach ($reservations as $row) $byRoom[(int) $row['room_id']][] = $row;
$paymentHolds = [];
if (payment_attempts_available($conn)) {
    $holds = $conn->query("SELECT p.*, rooms.room_name FROM payment_attempts p LEFT JOIN rooms ON rooms.id = p.room_id WHERE p.status = 'pending' AND p.expires_at > NOW() ORDER BY p.expires_at");
    while ($hold = $holds->fetch_assoc()) {
        try { $stay = payment_attempt_stay($hold); } catch (Throwable $error) { error_log('Calendar payment hold needs review: ' . (int) $hold['id']); continue; }
        if ($stay['check_in'] >= $endSql || $stay['check_out'] < $startSql) continue;
        $paymentHolds[] = $hold;
        $byRoom[(int) $hold['room_id']][] = ['payment_hold' => true, 'id' => (int) $hold['id'], 'full_name' => $hold['full_name'], 'check_in' => $stay['check_in'], 'check_out' => $stay['check_out'], 'expires_at' => $hold['expires_at']];
    }
}
$dates = [];
for ($day = 0; $day < $days; $day++) $dates[] = $start->modify('+' . $day . ' days');
$success = $_SESSION['reservation_success'] ?? '';
$error = $_SESSION['reservation_error'] ?? '';
unset($_SESSION['reservation_success'], $_SESSION['reservation_error']);

function calendar_entries($rows, $date) {
    $dayStart = $date->format('Y-m-d 00:00:00');
    $dayEnd = $date->modify('+1 day')->format('Y-m-d 00:00:00');
    return array_values(array_filter($rows, function ($row) use ($dayStart, $dayEnd) {
        $state = !empty($row['payment_hold']) ? 'pending' : reservation_state($row);
        if (!in_array($state, ['reserved', 'checked_in', 'pending'], true)) return false;
        $arrival = $row['scheduled_check_in'] ?? $row['check_in'];
        $departure = $row['scheduled_check_out'] ?? $row['check_out'];
        $overdue = $state === 'checked_in' && $departure < date('Y-m-d H:i:s');
        if ($overdue) $departure = max($departure, date('Y-m-d 23:59:59'));
        return $arrival < $dayEnd && $departure >= $dayStart;
    }));
}

function calendar_night_available($rows, $date) {
    $arrival = $date->format('Y-m-d 14:00:00');
    $departure = $date->modify('+1 day')->format('Y-m-d 12:00:00');
    foreach (calendar_entries($rows, $date) as $row) {
        $reservedStart = $row['scheduled_check_in'] ?? $row['check_in'];
        $reservedEnd = $row['scheduled_check_out'] ?? $row['check_out'];
        if (empty($row['payment_hold']) && reservation_state($row) === 'checked_in' && $reservedEnd < date('Y-m-d H:i:s')) $reservedEnd = max($reservedEnd, date('Y-m-d 23:59:59'));
        if ($reservedStart < $departure && $reservedEnd > $arrival) return false;
    }
    return true;
}
?>
<!doctype html>
<html lang="en"><head>
    <meta charset="utf-8"><meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Reservation calendar — Bongabong View Hotel</title>
    <link rel="stylesheet" href="style.css?v=<?php echo filemtime(__DIR__ . '/style.css'); ?>">
    <link rel="stylesheet" href="bookings.css?v=<?php echo filemtime(__DIR__ . '/bookings.css'); ?>">
</head><body>
<?php render_navbar(); ?>
<main class="page-wrapper" id="main-content">
    <div class="page-heading section-header-row">
        <div><p class="eyebrow">Arrivals, departures, and room availability</p><h1>Reservation calendar</h1><p class="page-description">Confirm arrivals and manage each stay. A reservation becomes occupied when you check the guest in.</p></div>
        <a href="index.php#rooms" class="primary-btn">Create a booking <?php echo ui_icon('plus'); ?></a>
    </div>
    <?php if ($success) { ?><div class="success-box page-alert" role="status"><?php echo e($success); ?></div><?php } ?>
    <?php if ($error) { ?><div class="error-box page-alert" role="alert"><?php echo e($error); ?></div><?php } ?>
    <section class="panel-box calendar-toolbar" aria-label="Calendar dates">
        <form method="GET" action="calendar.php" class="calendar-filters">
            <div><label for="calendar-date">Starting date</label><input type="date" id="calendar-date" name="date" value="<?php echo e($dateValue); ?>" required></div>
            <div><label for="calendar-days">View</label><select id="calendar-days" name="days"><?php foreach ([7, 14, 30] as $count) { ?><option value="<?php echo $count; ?>"<?php echo $days === $count ? ' selected' : ''; ?>><?php echo $count; ?> days</option><?php } ?></select></div>
            <button type="submit">Show dates</button>
            <a class="reset-link" href="calendar.php">Today</a>
        </form>
        <nav class="calendar-navigation" aria-label="Previous and next dates">
            <a href="calendar.php?date=<?php echo $start->modify('-' . $days . ' days')->format('Y-m-d'); ?>&amp;days=<?php echo $days; ?>" class="secondary-btn">← Previous</a>
            <span><?php echo e($start->format('M j') . ' – ' . $end->modify('-1 day')->format('M j, Y')); ?></span>
            <a href="calendar.php?date=<?php echo $end->format('Y-m-d'); ?>&amp;days=<?php echo $days; ?>" class="secondary-btn">Next →</a>
        </nav>
    </section>
    <div class="calendar-legend"><span class="booking-badge booking-badge--reserved">Reserved</span><span class="booking-badge booking-badge--checked_in">Checked in</span><span class="booking-badge booking-badge--pending">Payment hold</span><span class="booking-badge booking-badge--available">Available for the night</span><span>Each day shows arrivals and scheduled departures. Scroll sideways for more dates.</span></div>
    <section class="panel-box calendar-panel">
        <div class="table-scroll calendar-scroll" role="region" aria-label="Room reservations by date" tabindex="0">
        <table class="reservation-calendar"><caption class="sr-only">Room availability and reservations from <?php echo e($start->format('F j, Y')); ?></caption>
            <thead><tr><th scope="col">Room</th><?php foreach ($dates as $date) { $free = 0; foreach ($rooms as $room) if (calendar_night_available($byRoom[(int) $room['id']] ?? [], $date)) $free++; ?>
                <th scope="col" class="<?php echo $date->format('Y-m-d') === date('Y-m-d') ? 'calendar-today' : ''; ?>"><span><?php echo $date->format('D'); ?></span><strong><?php echo $date->format('M j'); ?></strong><small><?php echo $free; ?> rooms free</small></th>
            <?php } ?></tr></thead>
            <tbody><?php foreach ($rooms as $room) { ?><tr>
                <th scope="row"><a href="index.php?room_id=<?php echo (int) $room['id']; ?>#booking"><?php echo e($room['room_name']); ?></a><small><?php echo e($room['room_type']); ?></small></th>
                <?php foreach ($dates as $date) { $entries = calendar_entries($byRoom[(int) $room['id']] ?? [], $date); ?><td class="<?php echo $date->format('Y-m-d') === date('Y-m-d') ? 'calendar-today' : ''; ?>">
                    <?php foreach ($entries as $entry) { $state = !empty($entry['payment_hold']) ? 'pending' : reservation_state($entry); $arrival = $entry['scheduled_check_in'] ?? $entry['check_in']; $departure = $entry['scheduled_check_out'] ?? $entry['check_out']; ?>
                    <a href="<?php echo $state === 'pending' ? '#payment-holds' : '#reservation-' . (int) $entry['id']; ?>" class="calendar-entry booking-badge--<?php echo e($state); ?>"><strong><?php echo e($entry['full_name']); ?></strong><small><?php
                        $markers = [];
                        if ($state === 'pending') $markers[] = 'Payment hold until ' . date('g:i A', strtotime($entry['expires_at']));
                        if (substr($arrival, 0, 10) === $date->format('Y-m-d')) $markers[] = 'Arrival ' . date('g:i A', strtotime($arrival));
                        if (substr($departure, 0, 10) === $date->format('Y-m-d')) $markers[] = 'Departure ' . date('g:i A', strtotime($departure));
                        echo e($markers ? implode(' · ', $markers) : reservation_status($entry));
                    ?></small></a>
                    <?php } ?>
                    <?php if (calendar_night_available($byRoom[(int) $room['id']] ?? [], $date)) { ?><span class="calendar-free">Available for the night</span><?php } ?>
                </td><?php } ?>
            </tr><?php } ?>
            <?php if (!$rooms) { ?><tr><td colspan="<?php echo $days + 1; ?>" class="empty-row">No active rooms. Add or enable a room in Room Management.</td></tr><?php } ?>
            </tbody>
        </table></div>
    </section>
    <div class="section-header-row"><h2>Reservations in this view</h2><span class="section-count"><?php echo count($reservations); ?> stays</span></div>
    <?php if ($paymentHolds) { ?><section class="panel-box" id="payment-holds"><h2>Payments in progress</h2><p class="form-note">These rooms are temporarily held for the selected dates while the guest completes payment. They become reservations after confirmation.</p><?php foreach ($paymentHolds as $hold) { ?><p><?php echo e($hold['room_name'] ?? 'Room'); ?> · <?php echo e($hold['full_name']); ?> · Hold expires <?php echo e(date('g:i A', strtotime($hold['expires_at']))); ?></p><?php } ?></section><?php } ?>
    <div class="booking-list">
    <?php foreach ($reservations as $row) { $state = reservation_state($row); ?>
        <article class="panel-box booking-card" id="reservation-<?php echo (int) $row['id']; ?>">
            <div class="booking-card-heading"><div><p class="eyebrow">Reservation #<?php echo (int) $row['id']; ?></p><h2><?php echo e($row['full_name']); ?></h2><p><?php echo e($row['room_name'] ?? 'Removed room'); ?></p></div><span class="booking-badge booking-badge--<?php echo e($state); ?>"><?php echo e(reservation_status($row)); ?></span></div>
            <dl class="booking-details"><div><dt>Scheduled arrival</dt><dd><?php echo e(date('M j, Y · g:i A', strtotime($row['scheduled_check_in'] ?? $row['check_in']))); ?></dd></div><div><dt>Scheduled departure</dt><dd><?php echo e(date('M j, Y · g:i A', strtotime($row['scheduled_check_out'] ?? $row['check_out']))); ?></dd></div><div><dt>Payment</dt><dd><?php echo e($row['payment_method']); ?> · <?php echo money($row['total_amount']); ?></dd></div><div><dt>Contact</dt><dd><?php echo e($row['contact_number']); ?></dd></div></dl>
            <?php if ($state === 'checked_in' && $row['check_out'] < date('Y-m-d H:i:s')) { ?><p class="booking-notice">Scheduled departure has passed. The room remains occupied until staff checks the guest out.</p><?php } ?>
            <?php if ($row['actual_check_in']) { ?><p class="form-note">Checked in: <?php echo e($row['actual_check_in']); ?><?php if ($row['actual_check_out']) echo ' · Checked out: ' . e($row['actual_check_out']); ?></p><?php } ?>
            <div class="booking-actions"><?php render_reservation_actions($row, $dateValue, $days); ?><a href="receipt.php?id=<?php echo (int) $row['id']; ?>" class="receipt-link">View receipt <?php echo ui_icon('arrow-up'); ?></a></div>
        </article>
    <?php } ?>
    <?php if (!$reservations) { ?><div class="empty-card">No reservations for these dates. All availability is shown in the calendar above.</div><?php } ?>
    </div>
</main><?php render_footer(); ?></body></html>
