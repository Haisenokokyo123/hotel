<?php

function reservation_state($row) {
    $state = $row['reservation_state'] ?? $row['state'] ?? null;
    if (in_array($state, ['reserved', 'checked_in', 'checked_out', 'cancelled', 'no_show'], true)) return $state;
    if ((int) ($row['is_archived'] ?? 0) === 1 || $row['check_out'] <= date('Y-m-d H:i:s')) return 'checked_out';
    return $row['check_in'] <= date('Y-m-d H:i:s') ? 'checked_in' : 'reserved';
}

function reservation_status($row) {
    $labels = ['reserved' => 'Reserved', 'checked_in' => 'Checked in', 'checked_out' => 'Checked out', 'cancelled' => 'Cancelled', 'no_show' => 'No-show'];
    return $labels[reservation_state($row)];
}

function record_reservation_state($conn, $reservationId, $checkIn, $checkOut, $state = 'reserved', $staffId = null) {
    $actualArrival = $state === 'checked_in' ? date('Y-m-d H:i:s') : null;
    $statement = $conn->prepare('INSERT INTO reservation_states (reservation_id, state, scheduled_check_in, scheduled_check_out, actual_check_in, updated_by) VALUES (?, ?, ?, ?, ?, ?)');
    $statement->bind_param('issssi', $reservationId, $state, $checkIn, $checkOut, $actualArrival, $staffId);
    $statement->execute();
}

function reservation_conflict($conn, $roomId, $checkIn, $checkOut, $excludeId = 0, $lock = true) {
    $statement = $conn->prepare("SELECT r.id FROM reservations r
        LEFT JOIN reservation_states s ON s.reservation_id = r.id
        WHERE r.room_id = ? AND r.id <> ? AND r.is_archived = 0
        AND COALESCE(s.state, 'reserved') IN ('reserved', 'checked_in')
        AND r.check_in < ?
        AND (r.check_out > ? OR (s.state = 'checked_in' AND ? <= NOW()))
        LIMIT 1" . ($lock ? ' FOR UPDATE' : ''));
    $statement->bind_param('iisss', $roomId, $excludeId, $checkOut, $checkIn, $checkIn);
    $statement->execute();
    return $statement->get_result()->fetch_assoc();
}

function get_active_reservation($conn, $roomId) {
    $statement = $conn->prepare("SELECT r.*, s.state AS reservation_state,
        s.scheduled_check_in, s.scheduled_check_out, s.actual_check_in, s.actual_check_out
        FROM reservations r LEFT JOIN reservation_states s ON s.reservation_id = r.id
        WHERE r.room_id = ? AND r.is_archived = 0
        AND (s.state = 'checked_in' OR (s.state IS NULL AND r.check_in <= NOW() AND r.check_out > NOW()))
        ORDER BY r.id DESC LIMIT 1");
    $statement->bind_param('i', $roomId);
    $statement->execute();
    return $statement->get_result()->fetch_assoc() ?: null;
}

function reservation_available_actions($row, $now = null) {
    $now = $now ?? date('Y-m-d H:i:s');
    $state = reservation_state($row);
    if ($state === 'checked_in') return ['check_out'];
    if ($state !== 'reserved') return [];
    $actions = ['cancel'];
    if (substr($row['check_in'], 0, 10) <= substr($now, 0, 10) && $row['check_out'] > $now) $actions[] = 'check_in';
    if ($row['check_in'] <= $now) $actions[] = 'no_show';
    return $actions;
}

function change_reservation_state($conn, $reservationId, $action, $staffId) {
    $targets = ['check_in' => 'checked_in', 'check_out' => 'checked_out', 'cancel' => 'cancelled', 'no_show' => 'no_show'];
    if (!isset($targets[$action])) throw new InvalidArgumentException('Choose a valid reservation action.');
    $statement = $conn->prepare('SELECT room_id FROM reservations WHERE id = ?');
    $statement->bind_param('i', $reservationId);
    $statement->execute();
    $reference = $statement->get_result()->fetch_assoc();
    if (!$reference) throw new InvalidArgumentException('This reservation no longer exists.');
    $conn->begin_transaction();
    try {
        $statement = $conn->prepare('SELECT is_active FROM rooms WHERE id = ? FOR UPDATE');
        $statement->bind_param('i', $reference['room_id']);
        $statement->execute();
        $room = $statement->get_result()->fetch_assoc();
        $statement = $conn->prepare('SELECT r.*, s.state AS reservation_state FROM reservations r LEFT JOIN reservation_states s ON s.reservation_id = r.id WHERE r.id = ? FOR UPDATE');
        $statement->bind_param('i', $reservationId);
        $statement->execute();
        $row = $statement->get_result()->fetch_assoc();
        if (!$row || !in_array($action, reservation_available_actions($row), true)) {
            throw new InvalidArgumentException('This action is no longer available for this reservation. Refresh the calendar.');
        }
        if ($action === 'check_in') {
            if (!$room || !(int) $room['is_active']) throw new InvalidArgumentException('This room is disabled.');
            if (get_active_reservation($conn, (int) $row['room_id'])) throw new InvalidArgumentException('Check out the current guest before checking in this arrival.');
            // Early arrival must not overlap a different reservation or payment hold.
            $arrival = date('Y-m-d H:i:s');
            if (reservation_conflict($conn, (int) $row['room_id'], $arrival, $row['check_out'], $reservationId)) {
                throw new InvalidArgumentException('Another reservation overlaps this arrival.');
            }
            require_once __DIR__ . '/gcash.php';
            if (payment_hold_for_room($conn, (int) $row['room_id'], $arrival, $row['check_out'])) {
                throw new InvalidArgumentException('Another payment is holding this room for these dates.');
            }
        }
        if ($row['reservation_state'] === null) {
            record_reservation_state($conn, $reservationId, $row['check_in'], $row['check_out'], reservation_state($row), $staffId);
        }
        $state = $targets[$action];
        $statement = $conn->prepare("UPDATE reservation_states SET state = ?, updated_by = ?, updated_at = NOW(),
            actual_check_in = CASE WHEN ? = 'check_in' THEN NOW() ELSE actual_check_in END,
            actual_check_out = CASE WHEN ? = 'check_out' THEN NOW() ELSE actual_check_out END
            WHERE reservation_id = ?");
        $statement->bind_param('sissi', $state, $staffId, $action, $action, $reservationId);
        $statement->execute();
        if ($action !== 'check_in') {
            $statement = $conn->prepare("UPDATE reservations SET is_archived = 1,
                check_out = CASE WHEN ? = 'check_out' THEN NOW() ELSE check_out END WHERE id = ?");
            $statement->bind_param('si', $action, $reservationId);
            $statement->execute();
        }
        $conn->commit();
    } catch (Throwable $error) {
        $conn->rollback();
        throw $error;
    }
}

function render_reservation_actions($row, $returnDate = null, $days = 14) {
    $labels = ['check_in' => 'Check in', 'check_out' => 'Check out', 'cancel' => 'Cancel', 'no_show' => 'No-show'];
    foreach (reservation_available_actions($row) as $action) {
        $confirm = ['check_out' => 'Check out this guest?', 'cancel' => 'Cancel this reservation? Any paid amount remains recorded; this does not issue a refund.', 'no_show' => 'Mark this guest as a no-show? Any paid amount remains recorded; this does not issue a refund.'][$action] ?? null;
        echo '<form action="reservation_action.php" method="POST" class="reservation-action-form"' . ($confirm ? ' onsubmit="return confirm(' . e(json_encode($confirm)) . ');"' : '') . '>';
        echo '<input type="hidden" name="csrf_token" value="' . e(csrf_token()) . '"><input type="hidden" name="reservation_id" value="' . (int) $row['id'] . '"><input type="hidden" name="action" value="' . e($action) . '">';
        if ($returnDate !== null) echo '<input type="hidden" name="date" value="' . e($returnDate) . '">';
        echo '<input type="hidden" name="days" value="' . (int) $days . '">';
        echo '<button type="submit"' . (in_array($action, ['cancel', 'no_show'], true) ? ' class="danger-btn"' : '') . '>' . e($labels[$action]) . '</button></form>';
    }
}
