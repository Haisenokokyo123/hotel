<?php

class LoginRateLimitException extends RuntimeException {}

function auth_bucket($kind, $value) {
    return hash('sha256', $kind . ':' . $value);
}

function auth_limit_row($conn, $bucket, $windowSeconds) {
    $statement = $conn->prepare('INSERT IGNORE INTO auth_rate_limits (bucket, window_started) VALUES (?, NOW())');
    $statement->bind_param('s', $bucket);
    $statement->execute();
    $statement = $conn->prepare('SELECT attempts, window_started, blocked_until FROM auth_rate_limits WHERE bucket = ? FOR UPDATE');
    $statement->bind_param('s', $bucket);
    $statement->execute();
    $limit = $statement->get_result()->fetch_assoc();
    if ($limit['blocked_until'] && strtotime($limit['blocked_until']) > time()) {
        throw new LoginRateLimitException('Too many attempts. Please wait 15 minutes before trying again.');
    }
    if (strtotime($limit['window_started']) <= time() - $windowSeconds) {
        $statement = $conn->prepare('UPDATE auth_rate_limits SET attempts = 0, window_started = NOW(), blocked_until = NULL WHERE bucket = ?');
        $statement->bind_param('s', $bucket);
        $statement->execute();
        $limit['attempts'] = 0;
    }
    return $limit;
}

function auth_record_failure($conn, $bucket, $attempts, $maximum) {
    $attempts++;
    $blockedUntil = $attempts >= $maximum ? date('Y-m-d H:i:s', time() + 900) : null;
    $statement = $conn->prepare('UPDATE auth_rate_limits SET attempts = ?, blocked_until = ? WHERE bucket = ?');
    $statement->bind_param('iss', $attempts, $blockedUntil, $bucket);
    $statement->execute();
}

function authenticate_user($email, $password, $role = null) {
    if (!is_string($email) || !is_string($password)) return null;
    $email = strtolower(trim($email));
    if (strlen($email) > 100 || strlen($password) > 4096) return null;
    $conn = db_connect();
    $ipBucket = auth_bucket('login-ip', $_SERVER['REMOTE_ADDR'] ?? 'local');
    $accountBucket = auth_bucket('login-account', $email);
    $conn->begin_transaction();
    try {
        // Lock in a fixed order. Limits survive a new session or browser.
        $ipLimit = auth_limit_row($conn, $ipBucket, 900);
        $accountLimit = auth_limit_row($conn, $accountBucket, 900);
        $sql = 'SELECT id, name, password, role FROM users WHERE email = ?';
        if ($role !== null) $sql .= ' AND role = ?';
        $statement = $conn->prepare($sql . ' LIMIT 1');
        if ($role !== null) $statement->bind_param('ss', $email, $role);
        else $statement->bind_param('s', $email);
        $statement->execute();
        $user = $statement->get_result()->fetch_assoc();
        $hashed = $user && password_get_info($user['password'])['algoName'] !== 'unknown';
        // A fixed dummy hash makes unknown accounts take the normal verification path.
        $dummyHash = '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2uheWG/igi.';
        $valid = $user
            ? ($hashed ? password_verify($password, $user['password']) : hash_equals($user['password'], $password))
            : password_verify($password, $dummyHash) && false;
        if (!$valid || !in_array($user['role'], ['admin', 'staff', 'customer'], true)) {
            auth_record_failure($conn, $ipBucket, (int) $ipLimit['attempts'], 20);
            auth_record_failure($conn, $accountBucket, (int) $accountLimit['attempts'], 5);
            $conn->commit();
            return null;
        }
        // Existing plaintext accounts are upgraded after a successful sign-in.
        if (!$hashed || password_needs_rehash($user['password'], PASSWORD_BCRYPT)) {
            // Bcrypt cannot safely migrate legacy passwords longer than 72 bytes.
            if (strlen($password) <= 72) {
                $hash = password_hash($password, PASSWORD_BCRYPT);
                $statement = $conn->prepare('UPDATE users SET password = ? WHERE id = ? AND password = ?');
                $statement->bind_param('sis', $hash, $user['id'], $user['password']);
                $statement->execute();
            }
        }
        $statement = $conn->prepare('UPDATE auth_rate_limits SET attempts = 0, blocked_until = NULL, window_started = NOW() WHERE bucket = ?');
        $statement->bind_param('s', $accountBucket);
        $statement->execute();
        $conn->commit();
        unset($user['password']);
        return $user;
    } catch (Throwable $error) {
        $conn->rollback();
        throw $error;
    } finally {
        $conn->close();
    }
}

function register_customer($name, $email, $password) {
    return create_user_account($name, $email, $password, 'customer');
}

function register_staff($name, $email, $password) {
    return create_user_account($name, $email, $password, 'staff');
}

function create_user_account($name, $email, $password, $role) {
    if (!in_array($role, ['customer', 'staff'], true) || ($role === 'staff' && ($_SESSION['role'] ?? '') !== 'admin')) {
        throw new RuntimeException('Administrator access is required to create staff accounts.');
    }
    if (!is_string($name) || !is_string($email) || !is_string($password)) {
        throw new InvalidArgumentException('Please enter valid account details.');
    }
    $name = trim($name);
    $email = strtolower(trim($email));
    if ($name === '' || strlen($name) > 100 || strlen($email) > 100 || !filter_var($email, FILTER_VALIDATE_EMAIL)) {
        throw new InvalidArgumentException('Enter your name and a valid email address.');
    }
    if (!preg_match('/\A.{8,}\z/us', $password)) throw new InvalidArgumentException('Use a password with at least 8 characters.');
    if (strlen($password) > 72) throw new InvalidArgumentException('Your password is too long. Please use a shorter password.');
    $hash = password_hash($password, PASSWORD_BCRYPT);
    $conn = db_connect();
    $lock = 'register_' . substr(hash('sha256', $email), 0, 40);
    $locked = false;
    try {
        // Serialize registrations of the same email even on legacy tables without a unique index.
        $statement = $conn->prepare('SELECT GET_LOCK(?, 5) AS acquired');
        $statement->bind_param('s', $lock);
        $statement->execute();
        $locked = (int) $statement->get_result()->fetch_assoc()['acquired'] === 1;
        if (!$locked) throw new RuntimeException('Registration is busy. Please try again shortly.');
        $conn->begin_transaction();
        $statement = $conn->prepare('SELECT id FROM users WHERE email = ? LIMIT 1');
        $statement->bind_param('s', $email);
        $statement->execute();
        if ($statement->get_result()->fetch_assoc()) throw new InvalidArgumentException('This email is already registered.');
        $statement = $conn->prepare('INSERT INTO users (name, email, password, role) VALUES (?, ?, ?, ?)');
        $statement->bind_param('ssss', $name, $email, $hash, $role);
        $statement->execute();
        $userId = (int) $conn->insert_id;
        $conn->commit();
        return $userId;
    } catch (Throwable $error) {
        $conn->rollback();
        throw $error;
    } finally {
        if ($locked) {
            $statement = $conn->prepare('SELECT RELEASE_LOCK(?)');
            $statement->bind_param('s', $lock);
            $statement->execute();
        }
        $conn->close();
    }
}
