<?php

function guest_date_errors($arrival, $departure) {
    $errors = [];
    foreach (['arrival_date' => $arrival, 'departure_date' => $departure] as $field => $value) {
        $date = is_string($value) && preg_match('/\A\d{4}-\d{2}-\d{2}\z/', $value) ? DateTimeImmutable::createFromFormat('!Y-m-d', $value) : false;
        if (!$date || $date->format('Y-m-d') !== $value) $errors[$field] = 'Choose a valid ' . ($field === 'arrival_date' ? 'arrival' : 'departure') . ' date.';
    }
    if (!isset($errors['arrival_date']) && $arrival < date('Y-m-d')) $errors['arrival_date'] = 'Arrival must be today or later.';
    if (!$errors) {
        $nights = (int) (new DateTimeImmutable($arrival))->diff(new DateTimeImmutable($departure))->format('%r%a');
        if ($nights < 1) $errors['departure_date'] = 'Departure must be after arrival.';
        elseif ($nights > 365) $errors['departure_date'] = 'Choose a stay of up to 365 nights.';
    }
    return $errors;
}

function guest_booking_field_errors($values) {
    $errors = guest_date_errors($values['arrival_date'], $values['departure_date']);
    if ($values['full_name'] === '') $errors['full_name'] = 'Enter your full name.';
    elseif (strlen($values['full_name']) > 100) $errors['full_name'] = 'Use up to 100 characters for your name.';
    if ($values['contact_number'] === '') $errors['contact_number'] = 'Enter your contact number.';
    elseif (!preg_match('/\A[0-9]+\z/', $values['contact_number'])) $errors['contact_number'] = 'Enter numbers only for your contact number.';
    elseif (strlen($values['contact_number']) > 50) $errors['contact_number'] = 'Use up to 50 digits for your contact number.';
    if ($values['address'] === '') $errors['address'] = 'Enter your address.';
    elseif (strlen($values['address']) > 65535) $errors['address'] = 'Shorten your address.';
    return $errors;
}

function guest_room_available($conn, $roomId, $stay) {
    return !reservation_conflict($conn, $roomId, $stay['check_in'], $stay['check_out'], 0, false)
        && !payment_hold_for_room($conn, $roomId, $stay['check_in'], $stay['check_out']);
}

function guest_room_facts($room) {
    $beds = trim($room['bed_setup'] ?? '');
    if ($beds === '') {
        if (strcasecmp($room['room_type'], 'King Size Bed') === 0) $beds = '1 king-size bed';
        elseif (strcasecmp($room['room_type'], '2 Single Bed') === 0) $beds = '2 single beds';
    }
    $amenities = array_values(array_unique(array_filter(array_map('trim', preg_split('/[,\r\n]+/', $room['amenities'] ?? '')))));
    return ['beds' => $beds, 'capacity' => (int) ($room['guest_capacity'] ?? 0), 'amenities' => $amenities];
}

function guest_error_attributes($errors, $field, $prefix) {
    return ' aria-describedby="' . e($prefix . '-' . $field . '-error') . '"' . (isset($errors[$field]) ? ' aria-invalid="true"' : '');
}

function guest_field_error($errors, $field, $prefix) {
    echo '<small class="portal-field-error" aria-live="polite" id="' . e($prefix . '-' . $field . '-error') . '" data-field-error="' . e($field) . '"' . (isset($errors[$field]) ? '' : ' hidden') . '>' . e($errors[$field] ?? '') . '</small>';
}
